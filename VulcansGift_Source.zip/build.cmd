@echo off
setlocal
set "GIFT_BUILD_ROOT=%~dp0"
where cl >nul 2>nul
if errorlevel 1 call "%ProgramFiles(x86)%\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
if errorlevel 1 exit /b 1
cmake -S "%GIFT_BUILD_ROOT%vendor\libwebp" -B "%GIFT_BUILD_ROOT%webp_build" -G "NMake Makefiles" -DCMAKE_BUILD_TYPE=Release -DCMAKE_POLICY_DEFAULT_CMP0141=NEW -DCMAKE_MSVC_DEBUG_INFORMATION_FORMAT=Embedded -DCMAKE_TRY_COMPILE_CONFIGURATION=Release -DBUILD_SHARED_LIBS=OFF -DWEBP_BUILD_ANIM_UTILS=OFF -DWEBP_BUILD_CWEBP=OFF -DWEBP_BUILD_DWEBP=OFF -DWEBP_BUILD_GIF2WEBP=OFF -DWEBP_BUILD_IMG2WEBP=OFF -DWEBP_BUILD_VWEBP=OFF -DWEBP_BUILD_WEBPINFO=OFF -DWEBP_BUILD_LIBWEBPMUX=OFF -DWEBP_BUILD_WEBPMUX=OFF -DWEBP_BUILD_EXTRAS=OFF -DWEBP_USE_THREAD=ON
if errorlevel 1 exit /b 1
cmake --build "%GIFT_BUILD_ROOT%webp_build" --target webpdemux
if errorlevel 1 exit /b 1
cl /nologo /c /O2 /MD /Z7 /I "%GIFT_BUILD_ROOT%vendor\libwebp\src" "%GIFT_BUILD_ROOT%native\webp_adapter.c" /Fo"%GIFT_BUILD_ROOT%webp_build\vg_webp.obj"
if errorlevel 1 exit /b 1
lib /nologo /OUT:"%GIFT_BUILD_ROOT%webp_build\vg_webp.lib" "%GIFT_BUILD_ROOT%webp_build\vg_webp.obj"
if errorlevel 1 exit /b 1
set "WEBP_STATIC_DIR=%GIFT_BUILD_ROOT%webp_build"
cd /d "%GIFT_BUILD_ROOT%native"
cargo build --release
if errorlevel 1 exit /b 1
copy /Y target\release\apng_texture_trace.dll "%GIFT_BUILD_ROOT%VulcansGift.dll"
