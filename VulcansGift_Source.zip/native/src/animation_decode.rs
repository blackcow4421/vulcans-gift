//! Direct PNG/APNG and WebP decoding into composed, straight-alpha RGBA canvases.
use std::sync::Arc;
use crate::apng_decode;
use std::ffi::c_void;
#[link(name="vg_webp",kind="static")]
#[link(name="libwebpdemux",kind="static")]
#[link(name="libwebp",kind="static")]
#[link(name="libsharpyuv",kind="static")]
extern "C"{
 fn vg_webp_new(bytes:*const u8,size:usize,w:*mut u32,h:*mut u32,frames:*mut u32,loops:*mut u32)->*mut c_void;
 fn vg_webp_next(decoder:*mut c_void,output:*mut u8,size:usize,timestamp:*mut i32)->i32;
 fn vg_webp_reset(decoder:*mut c_void);fn vg_webp_delete(decoder:*mut c_void);
}
// The pointer is owned and exclusively used by one serialized Player. The Arc
// keeps encoded bytes alive until the native decoder is deleted.
struct Webp{decoder:usize,_bytes:Arc<[u8]>,timestamp:i32}
impl Drop for Webp{fn drop(&mut self){unsafe{vg_webp_delete(self.decoder as _)}}}
enum Backend{Png(apng_decode::Stream),Webp(Webp)}
pub struct Stream{backend:Backend,pub width:u32,pub height:u32,pub count:u32,pub plays:u32,pub index:u32,pub canvas:Vec<u8>,pub format:&'static str}
impl Stream{
 pub fn new(bytes:Arc<[u8]>)->Result<Self,String>{
  if bytes.len()>=12&&&bytes[..4]==b"RIFF"&&&bytes[8..12]==b"WEBP"{
   let(mut w,mut h,mut count,mut plays)=(0,0,0,0);
   let decoder=unsafe{vg_webp_new(bytes.as_ptr(),bytes.len(),&mut w,&mut h,&mut count,&mut plays)};
   if decoder.is_null(){return Err("invalid/unsupported WebP".into())}
   if count==1{plays=1}
   return Ok(Self{backend:Backend::Webp(Webp{decoder:decoder as usize,_bytes:bytes,timestamp:0}),width:w,height:h,count,plays,index:0,canvas:vec![0;w as usize*h as usize*4],format:"WebP"})
  }
  let png=apng_decode::Stream::new(bytes)?;let(w,h,count,plays)=(png.width,png.height,png.count,png.plays);
  Ok(Self{backend:Backend::Png(png),width:w,height:h,count,plays,index:0,canvas:vec![0;w as usize*h as usize*4],format:"APNG"})
 }
 pub fn next(&mut self)->Result<Option<f64>,String>{
  let delay=match &mut self.backend{
   Backend::Png(png)=>{let Some(delay)=png.next()?else{return Ok(None)};self.canvas.copy_from_slice(&png.canvas);delay},
   Backend::Webp(webp)=>{
    let mut timestamp=0;let result=unsafe{vg_webp_next(webp.decoder as _,self.canvas.as_mut_ptr(),self.canvas.len(),&mut timestamp)};
    if result==0{return Ok(None)}if result<0||timestamp<webp.timestamp{return Err("WebP frame decode/timestamp error".into())}
    let delay=(timestamp-webp.timestamp) as f64/1000.;webp.timestamp=timestamp;delay.max(0.001)
   }
  };self.index+=1;Ok(Some(delay))
 }
 pub fn restart(&mut self)->Result<(),String>{match &mut self.backend{Backend::Png(png)=>png.restart()?,Backend::Webp(webp)=>{unsafe{vg_webp_reset(webp.decoder as _)};webp.timestamp=0;}}self.index=0;self.canvas.fill(0);Ok(())}
}
