//! Local-DLL registration bridge: retain the installed official extender byte-for-byte.
use super::*;
static CORE:AtomicUsize=AtomicUsize::new(0);
extern "system"{fn LoadLibraryW(path:*const u16)->*mut c_void;fn GetProcAddress(module:*mut c_void,name:*const u8)->*mut c_void;}
fn entry(name:&[u8])->*mut c_void{let core=CORE.load(Ordering::Acquire);if core==0{return std::ptr::null_mut()}unsafe{GetProcAddress(core as _,name.as_ptr())}}
pub fn ensure(wrapper:&std::path::Path)->Result<(),String>{unsafe{
 let dir=std::path::PathBuf::from(std::env::var_os("APPDATA").ok_or("APPDATA unavailable")?).join("TKModManager/dll/0.46.0");
 let path=dir.join("script_extender.dll");
 if !path.is_file(){return Err("official TKMM 0.46.0 must remain installed; do not replace its version".into())}
 if std::fs::canonicalize(&path).ok()==std::fs::canonicalize(wrapper).ok(){return Err("wrapper replaced official 0.46.0; register as a separate local version".into())}
 let wide:Vec<u16>=path.to_string_lossy().encode_utf16().chain(Some(0)).collect();
 let handle=LoadLibraryW(wide.as_ptr());if handle.is_null(){return Err("could not load installed official extender".into())}
 CORE.store(handle as usize,Ordering::Release);
 let function=entry(b"se_status\0");if function.is_null(){return Err("official extender has no readiness export".into())}
 let status:extern "C" fn()->u32=std::mem::transmute(function);
 let deadline=std::time::Instant::now()+std::time::Duration::from_secs(45);
 loop{match status(){1=>{log!("CORE official 0.46.0 ready from {}; original DLL/config retained",path.display());return Ok(())},2|3=>return Err("official extender refused this game".into()),_=>{}}
  if std::time::Instant::now()>deadline{return Err("official extender readiness timed out; APNG hooks not installed".into())}
  std::thread::sleep(std::time::Duration::from_millis(100));
 }
}}
#[no_mangle]pub extern "C" fn se_status()->u32{let p=entry(b"se_status\0");if p.is_null(){return 0}unsafe{let f:extern "C" fn()->u32=std::mem::transmute(p);f()}}
#[no_mangle]pub extern "C" fn se_version()->*const std::ffi::c_char{let p=entry(b"se_version\0");if p.is_null(){return b"0.46.0.pending\0".as_ptr() as _}unsafe{let f:extern "C" fn()->*const std::ffi::c_char=std::mem::transmute(p);f()}}
