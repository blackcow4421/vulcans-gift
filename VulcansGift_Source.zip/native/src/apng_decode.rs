//! Streaming APNG composition. Keeps one canvas, not one canvas per frame.
use std::{io::Cursor,sync::Arc};
use png::{BlendOp,DisposeOp,FrameControl};
type Reader=png::Reader<Cursor<Arc<[u8]>>>;
pub struct Stream {
 bytes:Arc<[u8]>,reader:Reader,pub width:u32,pub height:u32,pub count:u32,pub plays:u32,
 pub index:u32,pub canvas:Vec<u8>,scratch:Vec<u8>,previous:Option<FrameControl>,saved:Vec<u8>,
}
pub fn over(src:&[u8],dst:&mut[u8]){
 let a=src[3] as u32;let b=dst[3] as u32;let n=a*255+b*(255-a);
 if n==0{dst.fill(0);return}
 for c in 0..3{dst[c]=((src[c] as u32*a*255+dst[c] as u32*b*(255-a)+n/2)/n) as u8;}
 dst[3]=((n+127)/255) as u8;
}
fn reader(bytes:Arc<[u8]>)->Result<Reader,String>{
 let mut d=png::Decoder::new(Cursor::new(bytes));d.set_limits(png::Limits{bytes:64*1024*1024});
 d.set_transformations(png::Transformations::EXPAND|png::Transformations::STRIP_16);
 d.read_info().map_err(|e|e.to_string())
}
impl Stream {
 pub fn new(bytes:Arc<[u8]>)->Result<Self,String>{
  let mut r=reader(bytes.clone())?;let info=r.info();let w=info.width;let h=info.height;
  let animation=info.animation_control.ok_or("not an APNG")?;
  if w==0||h==0||w>4096||h>4096||animation.num_frames==0||animation.num_frames>10000{return Err("APNG limits".into())}
  let size=(w as usize)*(h as usize)*4;let mut scratch=vec![0;size];
  // A default poster outside the animation must not become frame zero.
  if r.info().frame_control.is_none(){r.next_frame(&mut scratch).map_err(|e|e.to_string())?;}
  Ok(Self{bytes,reader:r,width:w,height:h,count:animation.num_frames,plays:animation.num_plays,index:0,canvas:vec![0;size],scratch,previous:None,saved:Vec::new()})
 }
 pub fn restart(&mut self)->Result<(),String>{
  self.reader=reader(self.bytes.clone())?;
  if self.reader.info().frame_control.is_none(){self.reader.next_frame(&mut self.scratch).map_err(|e|e.to_string())?;}
  self.index=0;self.canvas.fill(0);self.previous=None;self.saved.clear();Ok(())
 }
 fn clear(&mut self,f:FrameControl){
  for y in f.y_offset..f.y_offset+f.height{
   let start=((y*self.width+f.x_offset)*4) as usize;self.canvas[start..start+(f.width*4) as usize].fill(0);
  }
 }
 pub fn next(&mut self)->Result<Option<f64>,String>{
  if self.index>=self.count{return Ok(None)}
  if let Some(previous)=self.previous{
   match previous.dispose_op{DisposeOp::None=>{},DisposeOp::Background=>self.clear(previous),DisposeOp::Previous=>{
    if self.saved.len()==self.canvas.len(){self.canvas.copy_from_slice(&self.saved)}else{self.clear(previous)}
   }}
  }
  let output=self.reader.next_frame(&mut self.scratch).map_err(|e|e.to_string())?;
  let control=self.reader.info().frame_control.ok_or("missing APNG frame control")?;
  if control.x_offset.checked_add(control.width).ok_or("frame overflow")?>self.width || control.y_offset.checked_add(control.height).ok_or("frame overflow")?>self.height{return Err("frame outside APNG canvas".into())}
  if control.dispose_op==DisposeOp::Previous{self.saved.clone_from(&self.canvas)}
  let channels=match output.color_type{png::ColorType::Rgba=>4,png::ColorType::Rgb=>3,png::ColorType::GrayscaleAlpha=>2,png::ColorType::Grayscale=>1,_=>return Err("unexpanded palette".into())};
  if output.bit_depth!=png::BitDepth::Eight{return Err("unexpected sample depth".into())}
  for y in 0..control.height as usize{for x in 0..control.width as usize{
   let at=(y*control.width as usize+x)*channels;let raw=&self.scratch[at..at+channels];
   let pixel=match channels{4=>[raw[0],raw[1],raw[2],raw[3]],3=>[raw[0],raw[1],raw[2],255],2=>[raw[0],raw[0],raw[0],raw[1]],_=>[raw[0],raw[0],raw[0],255]};
   let dest=(((y+control.y_offset as usize)*self.width as usize+x+control.x_offset as usize)*4) as usize;
   if control.blend_op==BlendOp::Source{self.canvas[dest..dest+4].copy_from_slice(&pixel)}else{over(&pixel,&mut self.canvas[dest..dest+4])}
  }}
  self.previous=Some(control);self.index+=1;
  let duration=(control.delay_num as f64)/(if control.delay_den==0{100}else{control.delay_den} as f64);
  Ok(Some(duration.max(0.001)))
 }
}
#[cfg(test)]mod tests{use super::*;
 #[test]fn alpha_over(){let mut d=[0,0,255,128];over(&[255,0,0,128],&mut d);assert_eq!(d,[170,0,85,192]);}
 #[test]fn transparent_and_opaque(){let mut d=[10,20,30,255];over(&[100,200,40,0],&mut d);assert_eq!(d,[10,20,30,255]);over(&[9,8,7,255],&mut d);assert_eq!(d,[9,8,7,255]);}
}
