//! Read only the current launch list and its exposed movie packs. No profile rewriting.
use std::{collections::{HashMap,HashSet},path::{Path,PathBuf},fs::File,io::{Read,Seek,SeekFrom}};
#[derive(Clone,Debug)]pub struct Asset{pub pack:PathBuf,pub offset:u64,pub size:u64,pub compressed:bool}
impl Asset{pub fn read(&self)->Result<Vec<u8>,String>{
 if self.compressed{return Err("compressed image entry is unsupported".into())}
 let mut file=File::open(&self.pack).map_err(|e|e.to_string())?;
 if self.offset.checked_add(self.size).ok_or("entry overflow")?>file.metadata().map_err(|e|e.to_string())?.len(){return Err("entry outside pack".into())}
 let size=usize::try_from(self.size).map_err(|_|"image size exceeds address space")?;
 let mut data=Vec::new();data.try_reserve_exact(size).map_err(|_|"insufficient memory for encoded image")?;data.resize(size,0);
 file.seek(SeekFrom::Start(self.offset)).map_err(|e|e.to_string())?;file.read_exact(&mut data).map_err(|e|e.to_string())?;Ok(data)
}}
#[derive(Default)]pub struct Discovery{pub animations:HashMap<String,(Asset,u32,u32)>,pub png_sequences:HashMap<String,Vec<String>>,pub packs:Vec<PathBuf>}
fn le(b:&[u8],at:usize)->u32{u32::from_le_bytes(b[at..at+4].try_into().unwrap())}
pub fn parse_list(text:&str)->(Vec<String>,Vec<String>,HashSet<String>){
 let(mut dirs,mut mods,mut excluded)=(Vec::new(),Vec::new(),HashSet::new());
 for line in text.lines(){let line=line.trim();let Some((command,rest))=line.split_once(char::is_whitespace)else{continue};let rest=rest.trim();if !rest.starts_with('"'){continue}let Some(end)=rest[1..].find('"')else{continue};let value=rest[1..end+1].to_string();
  match command{"add_working_directory"=>dirs.push(value),"mod"=>mods.push(value),"exclude_pack_file"=>{excluded.insert(value.to_ascii_lowercase());},_=>{}}
 }(dirs,mods,excluded)
}
fn pack_type(path:&Path)->Result<u32,String>{let mut h=[0;8];File::open(path).and_then(|mut f|f.read_exact(&mut h)).map_err(|e|e.to_string())?;if &h[..4]!=b"PFH5"{return Err("unsupported pack version".into())}Ok(le(&h,4)&15)}
pub fn selected(game:&Path,text:&str)->Result<Vec<PathBuf>,String>{
 let(dirs,mods,excluded)=parse_list(text);let mut roots=vec![game.join("data")];roots.extend(dirs.iter().map(|d|{let p=PathBuf::from(d);if p.is_absolute(){p}else{game.join(p)}}));
 let mut packs=Vec::new();let mut names=HashSet::new();
 for name in mods{if excluded.contains(&name.to_ascii_lowercase()){continue}if Path::new(&name).components().count()!=1{return Err("mod directive must name one pack file".into())}
  let path=roots.iter().map(|d|d.join(&name)).find(|p|p.is_file()).ok_or_else(||format!("selected pack missing: {name}"))?;
  if names.insert(name.to_ascii_lowercase()){packs.push(path)}
 }
 for root in roots{if let Ok(list)=std::fs::read_dir(root){let mut movies:Vec<_>=list.flatten().map(|e|e.path()).filter(|p|p.extension().is_some_and(|e|e.eq_ignore_ascii_case("pack"))).collect();movies.sort_by_key(|p|p.file_name().unwrap().to_ascii_lowercase());
  for p in movies{let name=p.file_name().unwrap().to_string_lossy().to_ascii_lowercase();if !excluded.contains(&name)&&!names.contains(&name)&&pack_type(&p).ok()==Some(4){names.insert(name);packs.push(p);}}
 }}Ok(packs)
}
fn index(path:&Path)->Result<Vec<(String,Asset)>,String>{
 let mut f=File::open(path).map_err(|e|e.to_string())?;let length=f.metadata().map_err(|e|e.to_string())?.len();let mut h=[0;28];f.read_exact(&mut h).map_err(|e|e.to_string())?;
 if &h[..4]!=b"PFH5"||le(&h,4)&!15!=0{return Err("unsupported PFH5 flags".into())}
 let count=le(&h,16) as usize;let size=le(&h,20) as usize;let start=28+le(&h,12) as u64;
 if count>5_000_000||size>256*1024*1024||start+size as u64>length{return Err("invalid pack index".into())}
 f.seek(SeekFrom::Start(start)).map_err(|e|e.to_string())?;let mut data=vec![0;size];f.read_exact(&mut data).map_err(|e|e.to_string())?;
 let(mut pos,mut offset,mut entries)=(0usize,start+size as u64,Vec::new());
 for _ in 0..count{
  if pos+5>data.len(){return Err("truncated index".into())}let n=le(&data,pos) as u64;let compressed=data[pos+4]!=0;pos+=5;
  let end=pos+data[pos..].iter().position(|b|*b==0).ok_or("unterminated path")?;
  let name=std::str::from_utf8(&data[pos..end]).ok().map(|s|s.replace('\\',"/").to_ascii_lowercase());pos=end+1;
  if offset.checked_add(n).ok_or("entry overflow")?>length{return Err("entry outside pack".into())}
  if let Some(name)=name{if name.starts_with("ui/")&&(name.ends_with(".png")||name.ends_with(".webp"))&&!name.contains(['\t','\r','\n']){entries.push((name,Asset{pack:path.to_owned(),offset,size:n,compressed}));}}
  offset+=n;
 }Ok(entries)
}
fn animation(asset:&Asset)->Result<Option<(u32,u32)>,String>{
 if asset.compressed||asset.size<33{return Ok(None)}let mut f=File::open(&asset.pack).map_err(|e|e.to_string())?;f.seek(SeekFrom::Start(asset.offset)).map_err(|e|e.to_string())?;
 let mut h=[0;24];f.read_exact(&mut h).map_err(|e|e.to_string())?;if &h[..8]!=b"\x89PNG\r\n\x1a\n"||&h[12..16]!=b"IHDR"{return Ok(None)}
 let w=u32::from_be_bytes(h[16..20].try_into().unwrap());let height=u32::from_be_bytes(h[20..24].try_into().unwrap());let mut pos=asset.offset+8;let end=asset.offset+asset.size;
 for _ in 0..2048{if pos+12>end{return Ok(None)}f.seek(SeekFrom::Start(pos)).map_err(|e|e.to_string())?;let mut c=[0;8];f.read_exact(&mut c).map_err(|e|e.to_string())?;let n=u32::from_be_bytes(c[..4].try_into().unwrap()) as u64;
  if pos+12+n>end{return Err("PNG chunk outside entry".into())}match &c[4..8]{b"acTL"=>return Ok(Some((w,height))),b"IDAT"|b"IEND"=>return Ok(None),_=>{}}pos+=12+n;
 }Err("PNG chunk limit".into())
}
fn webp_dimensions(asset:&Asset)->Result<Option<(u32,u32)>,String>{
 if asset.compressed||asset.size<20{return Ok(None)}
 let mut f=File::open(&asset.pack).map_err(|e|e.to_string())?;f.seek(SeekFrom::Start(asset.offset)).map_err(|e|e.to_string())?;
 let mut data=[0u8;32];let len=(asset.size as usize).min(32);f.read_exact(&mut data[..len]).map_err(|e|e.to_string())?;
 if &data[..4]!=b"RIFF"||&data[8..12]!=b"WEBP"{return Ok(None)}
 if le(&data,4) as u64+8>asset.size{return Err("truncated RIFF image".into())}
 let size=match &data[12..16]{
  b"VP8X" if len>=30=>{let w=1+data[24] as u32+((data[25] as u32)<<8)+((data[26] as u32)<<16);let h=1+data[27] as u32+((data[28] as u32)<<8)+((data[29] as u32)<<16);(w,h)},
  b"VP8L" if len>=25&&data[20]==0x2f=>{let bits=le(&data,21);((bits&0x3fff)+1,((bits>>14)&0x3fff)+1)},
  b"VP8 " if len>=30&&data[23..26]==[0x9d,0x01,0x2a]=>{(u16::from_le_bytes([data[26],data[27]]) as u32&0x3fff,u16::from_le_bytes([data[28],data[29]]) as u32&0x3fff)},
  _=>return Ok(None)
 };Ok(Some(size))
}
fn png_dimensions(asset:&Asset)->Result<Option<(u32,u32)>,String>{
 if asset.compressed||asset.size<24{return Ok(None)}let mut f=File::open(&asset.pack).map_err(|e|e.to_string())?;f.seek(SeekFrom::Start(asset.offset)).map_err(|e|e.to_string())?;let mut h=[0u8;24];f.read_exact(&mut h).map_err(|e|e.to_string())?;
 if &h[..8]!=b"\x89PNG\r\n\x1a\n"||&h[12..16]!=b"IHDR"{return Ok(None)}Ok(Some((u32::from_be_bytes(h[16..20].try_into().unwrap()),u32::from_be_bytes(h[20..24].try_into().unwrap()))))
}
pub fn discover(game:&Path,text:&str)->Result<Discovery,String>{
 let packs=selected(game,text)?;let mut entries=HashMap::new();
 // The tested top-of-list precedence matches the existing Gift pack workflow.
 for path in &packs{for(name,asset) in index(path).map_err(|e|format!("{}: {e}",path.display()))?{entries.entry(name).or_insert(asset);}}
 let mut result=Discovery{packs,..Discovery::default()};let mut groups:HashMap<String,HashMap<usize,String>>=HashMap::new();
 for(name,asset) in &entries{
  if let Some(rest)=name.strip_prefix("ui/vulcans_gift/animations/"){if let Some((folder,file))=rest.rsplit_once("/ani/"){if let Some((stem,number))=file.trim_end_matches(".png").rsplit_once('_'){if number.len()>=3{if let Ok(n)=number.parse::<usize>(){groups.entry(format!("ui/{folder}/{stem}.png")).or_default().insert(n,name.clone());}}}}}
  if let Some((w,h))=animation(&asset)?{if w>0&&h>0&&w<=4096&&h<=4096{result.animations.insert(name.clone(),(asset.clone(),w,h));}}
 }
 // A .webp sibling overrides native animation for the matching PNG carrier.
 // The PNG remains a valid engine-readable layout/cover. No frame conversion.
 for(name,asset) in &entries{
  if let Some(stem)=name.strip_suffix(".webp"){
   let source=format!("{stem}.png");let Some(carrier)=entries.get(&source) else{continue};
   // A higher-priority static override suppresses a lower-priority WebP sibling.
   let rank=|a:&Asset|result.packs.iter().position(|p|*p==a.pack).unwrap_or(usize::MAX);
   if rank(asset)>rank(carrier){continue}
   if let Some((w,h))=webp_dimensions(asset)?{
    if w==0||h==0||w>4096||h>4096{continue}
    if let Some((cw,ch))=png_dimensions(carrier)?{if cw>0&&ch>0&&cw<=4096&&ch<=4096{result.animations.insert(source,(asset.clone(),cw,ch));}}
   }
  }
 }
 for (source,mut group) in groups{let mut frames=Vec::new();while let Some(path)=group.remove(&frames.len()){frames.push(path)}if !frames.is_empty(){result.png_sequences.insert(source,frames);}}
 Ok(result)
}
#[cfg(windows)]pub fn current()->Result<Discovery,String>{unsafe{
 #[link(name="shell32")]extern "system"{fn CommandLineToArgvW(command:*const u16,count:*mut i32)->*mut *mut u16;}
 extern "system"{fn GetCommandLineW()->*const u16;fn LocalFree(mem:*mut std::ffi::c_void)->*mut std::ffi::c_void;fn GetModuleFileNameW(module:*mut std::ffi::c_void,buf:*mut u16,n:u32)->u32;}
 unsafe fn wide(p:*const u16)->String{let mut n=0;while n<32768&&*p.add(n)!=0{n+=1}String::from_utf16_lossy(std::slice::from_raw_parts(p,n))}
 let mut buf=[0u16;32768];let n=GetModuleFileNameW(std::ptr::null_mut(),buf.as_mut_ptr(),32768) as usize;if n==0||n>=buf.len(){return Err("game path unavailable".into())}let path=PathBuf::from(String::from_utf16_lossy(&buf[..n]));let game=path.parent().ok_or("game folder missing")?;
 let mut count=0;let argv=CommandLineToArgvW(GetCommandLineW(),&mut count);if argv.is_null(){return Err("command line unavailable".into())}let args:Vec<String>=(0..count).map(|i|wide(*argv.add(i as usize))).collect();LocalFree(argv as _);
 let list=args.iter().skip(1).map(|a|a.trim_end_matches(';')).filter(|a|a.to_ascii_lowercase().ends_with(".txt")).map(|a|{let p=PathBuf::from(a);if p.is_absolute(){p}else{game.join(p)}}).find(|p|p.is_file()).ok_or("no supported active mod-list argument; refusing a profile guess")?;
 let data=std::fs::read(&list).map_err(|e|e.to_string())?;let text=if data.starts_with(&[0xff,0xfe]){let units:Vec<u16>=data[2..].chunks_exact(2).map(|x|u16::from_le_bytes([x[0],x[1]])).collect();String::from_utf16_lossy(&units)}else{String::from_utf8(data).map_err(|_|"mod list must be UTF-8 or UTF-16LE")?};
 crate::log!("RUNTIME active list {}",list.display());discover(game,&text)
}}
#[cfg(test)]mod tests{use super::*;#[test]fn exclusions(){let(d,m,e)=parse_list("add_working_directory \"C:/x\";\nmod \"a.pack\";\nexclude_pack_file \"b.pack\";");assert_eq!(d,["C:/x"]);assert_eq!(m,["a.pack"]);assert!(e.contains("b.pack"));}}

