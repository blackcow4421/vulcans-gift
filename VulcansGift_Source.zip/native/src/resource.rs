//! Verified CPU-image layout and existing resource lookup.
use super::*;
#[repr(C)]
pub(super) struct CpuImage {pub vtable:usize,pub width:u32,pub height:u32,pub count:u32,pub pad:u32,pub pixels:usize}
// Match the engine's read-only open-addressing lookup. Do not call a guessed ABI.
pub(super) fn find_entry(map:usize,key:usize)->Option<usize>{
 let table=ptr(map);let capacity=u32at(map+8) as usize;let empty=ptr(map+0x10);
 if table==0||capacity==0||capacity>2_000_000||key==0{return None}
 let hash=((key as u64>>32) as u32 ^ key as u32 ^ 0x4a545eed) as usize;
 let start=hash%capacity;
 for step in 0..capacity.min(4096){
  let i=(start+step)%capacity;let address=table.checked_add(i.checked_mul(0x98)?)?;
  let found=usize::from_le_bytes(read::<8>(address)?);
  if found==key{return Some(address+8)}
  if found==empty{return None}
 }None
}
// Texture descriptor: atlas dimensions +0/+4, region x/y +8/+12,
// padded region dimensions +16/+20, edge-padding flag +24. Verified in
// 0x141266850 and 0x1412991d0: the engine copies source rows at x/y + edge.
pub(super) fn valid_region(desc:&[u8;32],w:u32,h:u32,edge:u32,total:u32)->bool{
 let get=|at|u32::from_le_bytes(desc[at..at+4].try_into().unwrap());
 let(tw,th,x,y,rw,rh)=(get(0),get(4),get(8),get(12),get(16),get(20));
 if w==0||h==0||tw==0||th==0||tw>16384||th>16384||desc[24]>1{return false}
 let pad=if desc[24]!=0{if edge>16||total!=edge*2{return false}total}else{0};
 let Some(expected_w)=w.checked_add(pad)else{return false};let Some(expected_h)=h.checked_add(pad)else{return false};
 rw==expected_w&&rh==expected_h&&x.checked_add(rw).is_some_and(|end|end<=tw)&&y.checked_add(rh).is_some_and(|end|end<=th)
}
#[cfg(test)]
mod tests{
 use super::*;
 fn descriptor(tw:u32,th:u32,x:u32,y:u32,w:u32,h:u32,pad:u8)->[u8;32]{let mut b=[0;32];for(i,n)in [tw,th,x,y,w,h].iter().enumerate(){b[i*4..i*4+4].copy_from_slice(&n.to_le_bytes());}b[24]=pad;b}
 #[test]fn native_image_region(){assert!(valid_region(&descriptor(800,1088,0,0,800,1088,0),800,1088,1,2));}
 #[test]fn advisor_atlas_region(){assert!(valid_region(&descriptor(2048,2048,400,600,189,287,1),187,285,1,2));assert!(valid_region(&descriptor(2048,2048,400,600,187,285,0),187,285,1,2));}
 #[test]fn atlas_region_rejects_overflow_and_wrong_source(){assert!(!valid_region(&descriptor(2048,2048,2040,600,189,287,1),187,285,1,2));assert!(!valid_region(&descriptor(2048,2048,400,600,189,287,1),190,285,1,2));assert!(!valid_region(&descriptor(2048,2048,u32::MAX,600,189,287,1),187,285,1,2));assert!(!valid_region(&descriptor(2048,2048,400,600,189,287,1),187,285,2,2));}
 #[test]fn layout(){assert_eq!(std::mem::size_of::<CpuImage>(),32);assert_eq!(std::mem::offset_of!(CpuImage,pixels),24);}
 #[test]fn table_lookup(){
  let capacity=8usize;let empty=usize::MAX;let key=0x12345678usize;
  let start=(((key as u64>>32) as u32 ^ key as u32 ^ 0x4a545eed) as usize)%capacity;
  let mut table=vec![0u8;capacity*0x98];
  for i in 0..capacity{table[i*0x98..i*0x98+8].copy_from_slice(&empty.to_le_bytes());}
  table[start*0x98..start*0x98+8].copy_from_slice(&key.to_le_bytes());
  let map=[table.as_ptr() as usize,capacity,empty];
  assert_eq!(find_entry(map.as_ptr() as usize,key),Some(table.as_ptr() as usize+start*0x98+8));
  assert_eq!(find_entry(map.as_ptr() as usize,0),None);
  assert_eq!(find_entry(map.as_ptr() as usize,0x111),None);
 }
}
