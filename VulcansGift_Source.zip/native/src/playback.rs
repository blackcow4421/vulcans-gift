use super::*;
use super::animation_decode::Stream;
use super::resource::{CpuImage,find_entry,valid_region};
use std::{sync::{Mutex,atomic::{AtomicBool,AtomicU32}},time::{Instant,Duration}};
struct Buffer {image:CpuImage,pixels:Box<[u8]>}
struct Decoded {frames:Vec<Box<[u8]>>,delays:Vec<f64>}
struct Entry {asset:super::runtime_assets::Asset,w:u32,h:u32,offset:(usize,usize),player:OnceLock<Mutex<Player>>,reported:AtomicU32}
struct Player {
 cache:Option<Decoded>,
 stream:Stream,buffers:[Box<Buffer>;2],next_buffer:usize,offset:(usize,usize),
 due:Option<Instant>,seen:Option<Instant>,delay:f64,loops:u32,updates:u64,stopped:bool,
}
static PLAYERS:OnceLock<std::collections::HashMap<String,Entry>>=OnceLock::new();
pub fn contains(path:&str)->bool{PLAYERS.get().is_some_and(|m|m.contains_key(path))}
static BUSY:AtomicBool=AtomicBool::new(false);
static THREAD:AtomicU32=AtomicU32::new(0);
struct BusyGuard;
impl Drop for BusyGuard{fn drop(&mut self){BUSY.store(false,Ordering::Release);}}
#[cfg(test)]fn buffer()->Box<Buffer>{make_buffer(1200,1200)}
fn make_buffer(w:u32,h:u32)->Box<Buffer>{
 let pixels=vec![0;w as usize*h as usize*4].into_boxed_slice();
 let image=CpuImage{vtable:BASE.load(Ordering::Relaxed)+0x32670e0,width:w,height:h,count:w*h,pad:0,pixels:pixels.as_ptr() as usize};
 Box::new(Buffer{image,pixels})
}
pub fn prepare_runtime()->Result<(),String>{
 let found=super::runtime_assets::current()?;
 let mut entries=std::collections::HashMap::new();
 let mut manifest=String::from("VULCANS_GIFT\t1\n");
 for(path,(asset,w,h)) in found.animations{
  manifest.push_str(&format!("A\t{path}\n"));
  entries.insert(path,Entry{asset,w,h,offset:(0,0),player:OnceLock::new(),reported:AtomicU32::new(0)});
 }
 for(source,frames) in found.png_sequences{manifest.push_str(&format!("P\t{source}\t{}\n",frames.join("\t")));}
 log!("RUNTIME registry sources={} active_packs={}; no launcher or extracted APNG files",entries.len(),found.packs.len());
 let dir=std::path::PathBuf::from(std::env::var_os("LOCALAPPDATA").ok_or("LOCALAPPDATA missing")?).join("VulcansGiftNative");
 std::fs::create_dir_all(&dir).map_err(|e|e.to_string())?;
 std::thread::spawn(move||{
  let mut last=String::new();
  loop{
   if let Ok(token)=std::fs::read_to_string(dir.join("runtime_request.txt")){
    let token=token.trim();
    if !token.is_empty()&&token.len()<256&&!token.contains(['\t','\r','\n'])&&token!=last{
     let response=manifest.replacen("VULCANS_GIFT\t1\n",&format!("VULCANS_GIFT\t1\t{token}\n"),1);
     let temp=dir.join(format!("runtime_registry.{}.tmp",std::process::id()));
     if std::fs::write(&temp,response.as_bytes()).is_ok()&&std::fs::rename(&temp,dir.join("runtime_registry.tsv")).is_ok(){last=token.to_owned();record("RUNTIME handshake published for current Lua context");}
    }
   }
   std::thread::sleep(std::time::Duration::from_millis(500));
  }
 });
 PLAYERS.set(entries).map_err(|_|"registry already initialized")?;preload();Ok(())
}
fn preload(){std::thread::spawn(||{
   let budget=available_memory().saturating_sub(2*1024*1024*1024)*85/100;
   let mut used=0u64;log!("PLAYBACK decoded RAM cache budget={} MiB",budget/1024/1024);
   if let Some(entries)=PLAYERS.get(){for (path,entry) in entries{
    match entry.load(){
     Ok(mut p)=>{
      let need=p.stream.width as u64*p.stream.height as u64*4*p.stream.count as u64;
      // Keep the OS reserve and leave headroom for the game's subsequent allocations.
      if need<=budget.saturating_sub(used)&&need+2*1024*1024*1024<available_memory(){
       match p.warm_cache(){Ok(())=>{used+=need;log!("PLAYBACK RAM cached {} format={} frames={} MiB={}",path,p.stream.format,p.stream.count,need/1024/1024);},Err(e)=>{let _=p.stream.restart();p.delay=p.stream.next().ok().flatten().unwrap_or(0.1);log!("PLAYBACK RAM cache failed {path}: {e}")}}
       let _=entry.player.set(Mutex::new(p));
      }else{log!("PLAYBACK streaming fallback {path}");let _=entry.player.set(Mutex::new(p));}
     },Err(e)=>log!("PLAYBACK source rejected {path}: {e}")
    }
   }}
   log!("PLAYBACK preload complete decoded_MiB={}",used/1024/1024);
  });}
#[repr(C)]struct MemoryStatus{length:u32,load:u32,total_phys:u64,avail_phys:u64,total_page:u64,avail_page:u64,total_virtual:u64,avail_virtual:u64,extended:u64}
extern "system"{fn GlobalMemoryStatusEx(status:*mut MemoryStatus)->i32;}
fn available_memory()->u64{unsafe{let mut status:MemoryStatus=std::mem::zeroed();status.length=std::mem::size_of::<MemoryStatus>() as u32;if GlobalMemoryStatusEx(&mut status)!=0{status.avail_phys}else{0}}}
impl Entry{
 fn load(&self)->Result<Player,String>{
  let bytes=self.asset.read()?;
  let mut stream=Stream::new(bytes.into())?;
  if self.offset.0+stream.width as usize>self.w as usize||self.offset.1+stream.height as usize>self.h as usize{return Err("source outside canvas".into())}
  let delay=stream.next()?.ok_or("empty APNG")?;
  Ok(Player{cache:None,stream,buffers:[make_buffer(self.w,self.h),make_buffer(self.w,self.h)],next_buffer:0,offset:self.offset,due:None,seen:None,delay,loops:0,updates:0,stopped:false})
 }
}
impl Player {
 fn warm_cache(&mut self)->Result<(),String>{
  self.stream.restart()?;let mut frames=Vec::new();let mut delays=Vec::new();
  while let Some(delay)=self.stream.next()?{if frames.len()%16==0&&available_memory()<1024*1024*1024{return Err("RAM pressure during preload".into())}frames.push(self.stream.canvas.clone().into_boxed_slice());delays.push(delay);}
  self.stream.restart()?;self.delay=self.stream.next()?.ok_or("empty cached APNG")?;
  self.cache=Some(Decoded{frames,delays});Ok(())
 }
 fn advance(&mut self)->Result<Option<f64>,String>{
  if let Some(cache)=&self.cache{let at=self.stream.index as usize;if at>=cache.frames.len(){return Ok(None)}self.stream.index+=1;Ok(Some(cache.delays[at]))}else{self.stream.next()}
 }
 fn rewind(&mut self)->Result<(),String>{if self.cache.is_some(){self.stream.index=0;Ok(())}else{self.stream.restart()}}

 fn next_image(&mut self,now:Instant)->Result<Option<usize>,String>{

  if self.seen.is_some_and(|last|now.duration_since(last)>Duration::from_millis(300)){
   self.rewind()?;self.delay=self.advance()?.ok_or("empty restarted APNG")?;self.due=None;self.loops=0;self.stopped=false;
   record("PLAYBACK resumed visible target; restarted frame zero");
  }
  if self.stopped{return Ok(None)}
  self.seen=Some(now);
  if let Some(mut due)=self.due{
   if now<due{return Ok(None)}
   for _ in 0..if self.cache.is_some(){10001}else{4}{
    match self.advance()?{
     Some(delay)=>self.delay=delay,
     None=>{
      self.loops+=1;
      if self.stream.plays!=0 && self.loops>=self.stream.plays{self.stopped=true;record("PLAYBACK finite play count completed");return Ok(None)}
      self.rewind()?;self.delay=self.advance()?.ok_or("empty APNG loop")?;
      log!("PLAYBACK loop={} updates={}",self.loops,self.updates);
     }
    }
    due+=Duration::from_secs_f64(self.delay);
    if now<due{break}
   }
   if now>=due{due=now+Duration::from_secs_f64(self.delay)}
   self.due=Some(due);
  }else{self.due=Some(now+Duration::from_secs_f64(self.delay));}
  let target=&mut self.buffers[self.next_buffer];self.next_buffer^=1;
  target.pixels.fill(0);
  let width=self.stream.width as usize;let height=self.stream.height as usize;
  let canvas=if let Some(cache)=&self.cache{&cache.frames[(self.stream.index-1) as usize][..]}else{&self.stream.canvas[..]};
  for y in 0..height{
   let dest=((y+self.offset.1)*target.image.width as usize+self.offset.0)*4;
   target.pixels[dest..dest+width*4].copy_from_slice(&canvas[y*width*4..(y+1)*width*4]);
  }
  self.updates+=1;
  if self.updates==1||self.updates%100==0{log!("PLAYBACK frame={} updates={} tid={}",self.stream.index-1,self.updates,unsafe{GetCurrentThreadId()});}
  Ok(Some(&target.image as *const CpuImage as usize))
 }
}
pub unsafe fn tick(slot:usize,original_cpu:usize,path:&str){
 let Some(source)=PLAYERS.get().and_then(|m|m.get(path)) else{return};
 let Some(player)=source.player.get() else{return};
 if BUSY.swap(true,Ordering::AcqRel){return}let _busy=BusyGuard;
 let (w,h)={let Ok(p)=player.try_lock() else{return};(p.buffers[0].image.width,p.buffers[0].image.height)};
 if u32at(original_cpu+8)!=w||u32at(original_cpu+12)!=h{if source.reported.fetch_or(1,Ordering::Relaxed)&1==0{log!("PLAYBACK UI image size mismatch path={path} actual={}x{} expected={w}x{h}",u32at(original_cpu+8),u32at(original_cpu+12));}return}
 let base=BASE.load(Ordering::Relaxed);
 if ptr(original_cpu)!=base+0x32670e0{return}
 // SetImagePath has just assigned this image on the current UI owner thread.
 // Serialize uploads with BUSY, but allow the frontend/campaign UI owner to change.
 let tid=GetCurrentThreadId();let previous=THREAD.swap(tid,Ordering::AcqRel);
 if previous!=0&&previous!=tid{log!("PLAYBACK UI thread transition {previous}->{tid} path={path}");}
 let manager=ptr(base+0x3f5a6a8);let key=ptr(slot+0x50);
 let Some(entry)=find_entry(manager+0x10,key) else{return};let texture=ptr(entry+8);
 let Some(descriptor)=read::<32>(entry+0x38) else{return};
 // Keep the engine's existing atlas descriptor. Its uploader uses this region;
 // never synthesize a full-atlas image or replace other UI resources.
 let edge=u32at(base+0x3f5a858);let total=u32at(base+0x3f5a7e8);
 if texture==0||!valid_region(&descriptor,w,h,edge,total){
  if source.reported.fetch_or(2,Ordering::Relaxed)&2==0{log!("PLAYBACK invalid UI region path={path} descriptor={descriptor:02x?} source={w}x{h} edge={edge} total={total}");}return
 }
 if (u32at(entry+0x38)!=w||u32at(entry+0x3c)!=h)&&source.reported.fetch_or(4,Ordering::Relaxed)&4==0{log!("PLAYBACK atlas region accepted path={path} atlas={}x{} source={w}x{h}",u32at(entry+0x38),u32at(entry+0x3c));}

 if read::<8>(base+0x123de80)!=Some([0x48,0x89,0x5c,0x24,0x10,0x57,0x48,0x83]){return}
 let image={
  let Ok(mut p)=player.try_lock() else{return};
  match p.next_image(Instant::now()){
   Ok(Some(image))=>image,Ok(None)=>return,Err(e)=>{p.stopped=true;log!("PLAYBACK stopped decode error {e}");original_cpu}
  }
 };
 // The inspected upload path consumes CPU pixels inside the call. Both image
 // objects and both backing allocations remain allocated for the process lifetime.
 let update:unsafe extern "C" fn(usize,usize)=std::mem::transmute(base+0x123de80);
 update(entry,image);
 if let Ok(p)=player.try_lock(){if p.updates==1||p.updates%100==0{log!("PLAYBACK upload returned entry=0x{entry:x} texture=0x{texture:x} tid={tid} updates={}",p.updates);}}
 if find_entry(manager+0x10,key)!=Some(entry)||ptr(entry+8)!=texture{
  if let Ok(mut p)=player.try_lock(){p.stopped=true;}record("PLAYBACK stopped: resource identity changed");
 }
}
#[cfg(test)]mod tests{
 use super::*;
 fn fixture()->Player{
  let mut bytes=Vec::new();
  {
   let mut encoder=png::Encoder::new(&mut bytes,4,4);
   encoder.set_color(png::ColorType::Rgba);encoder.set_depth(png::BitDepth::Eight);
   encoder.set_animated(203,0).unwrap();encoder.set_frame_delay(27,1000).unwrap();
   let mut writer=encoder.write_header().unwrap();
   for i in 0..203u32{let mut rgba=vec![0u8;4*4*4];for pixel in rgba.chunks_exact_mut(4){pixel.copy_from_slice(&[i as u8,(i/2) as u8,200,128]);}writer.write_image_data(&rgba).unwrap();}
   writer.finish().unwrap();
  }
  let mut stream=Stream::new(bytes.into()).unwrap();let delay=stream.next().unwrap().unwrap();
  Player{cache:None,stream,buffers:[buffer(),buffer()],next_buffer:0,offset:(219,86),due:None,seen:None,delay,loops:0,updates:0,stopped:false}
 }
 #[test]fn cached_frames_match_streaming(){
  let mut cached=fixture();cached.warm_cache().unwrap();let mut original=fixture();
  assert_eq!(cached.cache.as_ref().unwrap().frames.len(),203);
  for i in 0..203usize{
   assert_eq!(&cached.cache.as_ref().unwrap().frames[i][..],&original.stream.canvas[..]);
   if i<202{let a=cached.advance().unwrap();let b=original.stream.next().unwrap();assert_eq!(a,b);}
  }
  assert!(cached.advance().unwrap().is_none());cached.rewind().unwrap();assert!(cached.advance().unwrap().is_some());
  assert_eq!(cached.stream.index,1);
 }
 #[test]fn timing_and_pause(){
  let mut p=fixture();let now=Instant::now();assert!(p.next_image(now).unwrap().is_some());assert_eq!(p.stream.index,1);
  assert!(p.next_image(now+Duration::from_millis(10)).unwrap().is_none());
  assert!(p.next_image(now+Duration::from_millis(40)).unwrap().is_some());assert_eq!(p.stream.index,2);
  assert!(p.next_image(now+Duration::from_secs(1)).unwrap().is_some());assert_eq!(p.stream.index,1);
 }
 #[test]fn bounded_buffers_and_loop(){
  let mut p=fixture();let pointers=[p.buffers[0].pixels.as_ptr(),p.buffers[1].pixels.as_ptr()];let start=Instant::now();
  for ms in (0..6200).step_by(20){p.next_image(start+Duration::from_millis(ms)).unwrap();}
  assert!(p.loops>=1);assert_eq!(p.buffers[0].pixels.as_ptr(),pointers[0]);assert_eq!(p.buffers[1].pixels.as_ptr(),pointers[1]);
  assert!(p.updates>200);
 }
}
