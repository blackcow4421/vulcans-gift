use super::*;
use super::animation_decode::Stream;
use super::resource::{CpuImage,find_entry,valid_region,region_source_size};
use std::{sync::{Mutex,atomic::{AtomicBool,AtomicU32}},time::{Instant,Duration}};
struct Buffer {image:CpuImage,pixels:Box<[u8]>}
struct Decoded {frames:Vec<Box<[u8]>>,delays:Vec<f64>}
struct FirstFrame{pixels:Vec<u8>,w:u32,h:u32}
struct Entry {first:OnceLock<Result<FirstFrame,String>>,preserve_size:bool,asset:super::runtime_assets::Asset,w:u32,h:u32,offset:(usize,usize),player:OnceLock<Mutex<Player>>,reported:AtomicU32}
struct Player {
 preserve_size:bool,cache:Option<Decoded>,card_selected:Option<bool>,card_done:bool,
 stream:Stream,buffers:[Box<Buffer>;2],next_buffer:usize,offset:(usize,usize),
 due:Option<Instant>,seen:Option<Instant>,delay:f64,loops:u32,updates:u64,stopped:bool,
}
static PLAYERS:OnceLock<std::collections::HashMap<String,Entry>>=OnceLock::new();
// These buffers remain allocated for the process lifetime, just like Player buffers.
static INITIAL_IMAGES:OnceLock<Mutex<std::collections::HashMap<(String,u32,u32),Box<Buffer>>>>=OnceLock::new();
pub fn initial_upload_image(path:&str,w:u32,h:u32)->Option<usize>{
 if w==0||h==0||w>4096||h>4096{return None}
 let entry=PLAYERS.get()?.get(path)?;
 let mut images=INITIAL_IMAGES.get_or_init(||Mutex::new(std::collections::HashMap::new())).lock().ok()?;
 let key=(path.to_owned(),w,h);
 if let Some(image)=images.get(&key){return Some(&image.image as *const CpuImage as usize)}
 let first=entry.initial_frame()?;let mut image=make_buffer(w,h);
 fit_rgba(&first.pixels,first.w,first.h,&mut image.pixels,w,h,entry.preserve_size);
 let result=&image.image as *const CpuImage as usize;
 images.insert(key,image);Some(result)
}
pub fn contains(path:&str)->bool{PLAYERS.get().is_some_and(|m|m.contains_key(path))}
// Native cards must finish the engine's carrier assignment before an animation
// frame is uploaded. This includes WebP, not only APNG.
pub fn defer_card_upload(path:&str)->bool{
 path.contains("/stills/unitcards/") && contains(path)
}
static BUSY:AtomicBool=AtomicBool::new(false);
static THREAD:AtomicU32=AtomicU32::new(0);
struct BusyGuard;
impl Drop for BusyGuard{fn drop(&mut self){BUSY.store(false,Ordering::Release);}}
#[cfg(test)]fn buffer()->Box<Buffer>{make_buffer(1200,1200)}
fn make_buffer(w:u32,h:u32)->Box<Buffer>{
 let pixels=vec![0;w as usize*h as usize*4].into_boxed_slice();
 let image=CpuImage{vtable:BASE.load(Ordering::Relaxed)+0x32670e0,width:w,height:h,count:w*h,pad:0,pixels:pixels.as_ptr() as usize};
 Box::new(Buffer{image,pixels})
}
pub fn prepare_runtime()->Result<(),String>{
 let found=super::runtime_assets::current()?;
 let mut entries=std::collections::HashMap::new();
 let mut manifest=String::from("VULCANS_GIFT\t1\n");
 for(path,(asset,w,h)) in found.animations{
  manifest.push_str(&format!("A\t{path}\n"));
  let preserve_size=path.contains("/large_panel/");
  entries.insert(path,Entry{first:OnceLock::new(),preserve_size,asset,w,h,offset:(0,0),player:OnceLock::new(),reported:AtomicU32::new(0)});
 }
 for(source,frames) in found.png_sequences{manifest.push_str(&format!("P\t{source}\t{}\n",frames.join("\t")));}
 log!("RUNTIME registry sources={} active_packs={}; no launcher or extracted APNG files",entries.len(),found.packs.len());
 let dir=std::path::PathBuf::from(std::env::var_os("LOCALAPPDATA").ok_or("LOCALAPPDATA missing")?).join("VulcansGiftNative");
 std::fs::create_dir_all(&dir).map_err(|e|e.to_string())?;
 std::thread::spawn(move||{
  let mut last=String::new();
  loop{
   if let Ok(token)=std::fs::read_to_string(dir.join("runtime_request.txt")){
    let token=token.trim();
    if !token.is_empty()&&token.len()<256&&!token.contains(['\t','\r','\n'])&&token!=last{
     let response=manifest.replacen("VULCANS_GIFT\t1\n",&format!("VULCANS_GIFT\t1\t{token}\n"),1);
     let temp=dir.join(format!("runtime_registry.{}.tmp",std::process::id()));
     if std::fs::write(&temp,response.as_bytes()).is_ok()&&std::fs::rename(&temp,dir.join("runtime_registry.tsv")).is_ok(){last=token.to_owned();diagnostic!("RUNTIME handshake published for current Lua context");}
    }
   }
   std::thread::sleep(std::time::Duration::from_millis(500));
  }
 });
 PLAYERS.set(entries).map_err(|_|"registry already initialized")?;preload();Ok(())
}
fn preload(){std::thread::spawn(||{
   let budget=available_memory().saturating_sub(2*1024*1024*1024)*85/100;
   let mut used=0u64;diagnostic!("PLAYBACK decoded RAM cache budget={} MiB",budget/1024/1024);
   if let Some(entries)=PLAYERS.get(){for (path,entry) in entries{
    match entry.load(){
     Ok(mut p)=>{
      let need=p.buffers[0].image.width as u64*p.buffers[0].image.height as u64*4*p.stream.count as u64;
      // Keep the OS reserve and leave headroom for the game's subsequent allocations.
      if need<=budget.saturating_sub(used)&&need+2*1024*1024*1024<available_memory(){
       match p.warm_cache(){Ok(())=>{used+=need;diagnostic!("PLAYBACK RAM cached {} format={} frames={} MiB={}",path,p.stream.format,p.stream.count,need/1024/1024);},Err(e)=>{let _=p.stream.restart();p.delay=p.stream.next().ok().flatten().unwrap_or(0.1);log!("PLAYBACK RAM cache failed {path}: {e}")}}
       let _=entry.player.set(Mutex::new(p));
      }else{diagnostic!("PLAYBACK streaming fallback {path}");let _=entry.player.set(Mutex::new(p));}
     },Err(e)=>log!("PLAYBACK source rejected {path}: {e}")
    }
   }}
   diagnostic!("PLAYBACK preload complete decoded_MiB={}",used/1024/1024);
  });}
#[repr(C)]struct MemoryStatus{length:u32,load:u32,total_phys:u64,avail_phys:u64,total_page:u64,avail_page:u64,total_virtual:u64,avail_virtual:u64,extended:u64}
extern "system"{fn GlobalMemoryStatusEx(status:*mut MemoryStatus)->i32;}
fn available_memory()->u64{unsafe{let mut status:MemoryStatus=std::mem::zeroed();status.length=std::mem::size_of::<MemoryStatus>() as u32;if GlobalMemoryStatusEx(&mut status)!=0{status.avail_phys}else{0}}}
 // Center within the PNG carrier canvas; shrink oversized sources, never enlarge.
// Interpolate premultiplied colors to avoid fringes at transparent edges.
fn fit_rgba(src:&[u8],sw:u32,sh:u32,dst:&mut [u8],dw:u32,dh:u32,preserve_size:bool){
 dst.fill(0);if sw==dw&&sh==dh{dst.copy_from_slice(src);return}
  if preserve_size&&sw<=dw&&sh<=dh{
   let ox=(dw-sw) as usize/2;let oy=(dh-sh) as usize/2;
   for y in 0..sh as usize{let from=y*sw as usize*4;let to=((y+oy)*dw as usize+ox)*4;dst[to..to+sw as usize*4].copy_from_slice(&src[from..from+sw as usize*4]);}
   return
  }
 let scale=(dw as f64/sw as f64).min(dh as f64/sh as f64);
 let rw=((sw as f64*scale).round() as usize).max(1).min(dw as usize);
 let rh=((sh as f64*scale).round() as usize).max(1).min(dh as usize);
 let ox=(dw as usize-rw)/2;let oy=(dh as usize-rh)/2;
 for y in 0..rh{
  let fy=((y as f64+0.5)*sh as f64/rh as f64-0.5).clamp(0.0,sh as f64-1.0);let y0=fy.floor() as usize;let y1=(y0+1).min(sh as usize-1);let ty=fy-y0 as f64;
  for x in 0..rw{
   let fx=((x as f64+0.5)*sw as f64/rw as f64-0.5).clamp(0.0,sw as f64-1.0);let x0=fx.floor() as usize;let x1=(x0+1).min(sw as usize-1);let tx=fx-x0 as f64;
   let points=[(x0,y0,(1.0-tx)*(1.0-ty)),(x1,y0,tx*(1.0-ty)),(x0,y1,(1.0-tx)*ty),(x1,y1,tx*ty)];
   let mut a=0.0;let mut rgb=[0.0;3];
   for(px,py,w)in points{let i=(py*sw as usize+px)*4;let alpha=src[i+3] as f64*w;a+=alpha;for c in 0..3{rgb[c]+=src[i+c] as f64*alpha;}}
   let i=((y+oy)*dw as usize+x+ox)*4;dst[i+3]=a.round() as u8;if a>0.0{for c in 0..3{dst[i+c]=(rgb[c]/a).round() as u8;}}
  }
 }
}
impl Entry{
 fn initial_frame(&self)->Option<&FirstFrame>{self.first.get_or_init(||{
  let mut stream=Stream::new(self.asset.read()?.into())?;
  stream.next()?.ok_or("empty initial card animation")?;
  Ok(FirstFrame{pixels:stream.canvas,w:stream.width,h:stream.height})
 }).as_ref().ok()}
 fn load(&self)->Result<Player,String>{
  let bytes=self.asset.read()?;
  let mut stream=Stream::new(bytes.into())?;
  if stream.width!=self.w||stream.height!=self.h{diagnostic!("PLAYBACK aspect-fit {}x{} into PNG canvas {}x{}",stream.width,stream.height,self.w,self.h);}
  let delay=stream.next()?.ok_or("empty APNG")?;
  Ok(Player{preserve_size:self.preserve_size,cache:None,card_selected:None,card_done:false,stream,buffers:[make_buffer(self.w,self.h),make_buffer(self.w,self.h)],next_buffer:0,offset:self.offset,due:None,seen:None,delay,loops:0,updates:0,stopped:false})
 }
}
impl Player {
 fn warm_cache(&mut self)->Result<(),String>{
  self.stream.restart()?;let mut frames=Vec::new();let mut delays=Vec::new();
  while let Some(delay)=self.stream.next()?{if frames.len()%16==0&&available_memory()<1024*1024*1024{return Err("RAM pressure during preload".into())}let mut pixels=vec![0;self.buffers[0].pixels.len()];fit_rgba(&self.stream.canvas,self.stream.width,self.stream.height,&mut pixels,self.buffers[0].image.width,self.buffers[0].image.height,self.preserve_size);frames.push(pixels.into_boxed_slice());delays.push(delay);}
  self.stream.restart()?;self.delay=self.stream.next()?.ok_or("empty cached APNG")?;
  self.cache=Some(Decoded{frames,delays});Ok(())
 }
 fn advance(&mut self)->Result<Option<f64>,String>{
  if let Some(cache)=&self.cache{let at=self.stream.index as usize;if at>=cache.frames.len(){return Ok(None)}self.stream.index+=1;Ok(Some(cache.delays[at]))}else{self.stream.next()}
 }
 fn rewind(&mut self)->Result<(),String>{if self.cache.is_some(){self.stream.index=0;Ok(())}else{self.stream.restart()}}

 fn select_card(&mut self,selected:bool)->Result<(),String>{
  if self.card_selected!=Some(selected){self.card_selected=Some(selected);self.card_done=false;self.rewind()?;self.delay=self.advance()?.ok_or("empty card animation")?;self.due=None;self.seen=None;self.stopped=false;self.loops=0;diagnostic!("CARD selected={selected}; reset to first frame");}Ok(())
 }
 fn next_image(&mut self,now:Instant)->Result<Option<usize>,String>{
  if self.card_selected.is_some()&&(self.card_selected==Some(false)||self.card_done){
   if self.due.is_some(){return Ok(None)}self.due=Some(now);return self.render_image()
  }


  if self.seen.is_some_and(|last|now.duration_since(last)>Duration::from_millis(300)){
   self.rewind()?;self.delay=self.advance()?.ok_or("empty restarted APNG")?;self.due=None;self.loops=0;self.stopped=false;
   diagnostic!("PLAYBACK resumed visible target; restarted frame zero");
  }
  if self.stopped{return Ok(None)}
  self.seen=Some(now);
  if let Some(mut due)=self.due{
   if now<due{return Ok(None)}
   for _ in 0..if self.cache.is_some(){10001}else{4}{
    match self.advance()?{
     Some(delay)=>self.delay=delay,
     None=>{
      self.loops+=1;
      if self.card_selected.is_some(){self.rewind()?;self.delay=self.advance()?.ok_or("empty completed card")?;self.card_done=true;self.due=Some(now);record("CARD one-shot complete; holding first frame");return self.render_image()}
      if self.stream.plays!=0 && self.loops>=self.stream.plays{self.stopped=true;record("PLAYBACK finite play count completed");return Ok(None)}
      self.rewind()?;self.delay=self.advance()?.ok_or("empty APNG loop")?;
      diagnostic!("PLAYBACK loop={} updates={}",self.loops,self.updates);
     }
    }
    due+=Duration::from_secs_f64(self.delay);
    if now<due{break}
   }
   if now>=due{due=now+Duration::from_secs_f64(self.delay)}
   self.due=Some(due);
  }else{self.due=Some(now+Duration::from_secs_f64(self.delay));}
  self.render_image()
 }
 // Reuse the already composed frame when the engine reassigns the PNG carrier.
 // No decoding, frame advancement or additional pixel copy is needed.
 fn retained_image(&self)->Option<usize>{
  if self.updates==0{return None}
  Some(&self.buffers[self.next_buffer^1].image as *const CpuImage as usize)
 }
 fn render_image(&mut self)->Result<Option<usize>,String>{
  let target=&mut self.buffers[self.next_buffer];self.next_buffer^=1;
  if let Some(cache)=&self.cache{target.pixels.copy_from_slice(&cache.frames[(self.stream.index-1) as usize]);}
  else{fit_rgba(&self.stream.canvas,self.stream.width,self.stream.height,&mut target.pixels,target.image.width,target.image.height,self.preserve_size);}
  self.updates+=1;
  if self.updates==1||self.updates%100==0{diagnostic!("PLAYBACK frame={} updates={} tid={}",self.stream.index-1,self.updates,unsafe{GetCurrentThreadId()});}
  Ok(Some(&target.image as *const CpuImage as usize))
 }
}
fn card_selection(component:usize)->Option<bool>{
 let state=ptr(ptr(component.checked_add(0x170)?)+0x38);let text=ca_path(state)?;
 match text.as_str(){"selected"|"selected_hover"|"selected_down"=>Some(true),"not_selected"|"active"|"hover"|"inactive"|"default"=>Some(false),_=>None}
}
pub unsafe fn tick(slot:usize,original_cpu:usize,path:&str,component:usize){
 let Some(source)=PLAYERS.get().and_then(|m|m.get(path)) else{return};
 let Some(player)=source.player.get() else{return};
 if BUSY.swap(true,Ordering::AcqRel){return}let _busy=BusyGuard;
 let (w,h)={let Ok(p)=player.try_lock() else{return};(p.buffers[0].image.width,p.buffers[0].image.height)};
 let base=BASE.load(Ordering::Relaxed);
 if original_cpu!=0&&ptr(original_cpu)!=base+0x32670e0{return}
 // SetImagePath has just assigned this image on the current UI owner thread.
 // Serialize uploads with BUSY, but allow the frontend/campaign UI owner to change.
 let tid=GetCurrentThreadId();let previous=THREAD.swap(tid,Ordering::AcqRel);
 if previous!=0&&previous!=tid{diagnostic!("PLAYBACK UI thread transition {previous}->{tid} path={path}");}
 let manager=ptr(base+0x3f5a6a8);let original_key=ptr(slot+0x50);
 // The UI image reference at slot+8 carries its bound atlas key at +0x20.
 // Engine-generated card variants may use <original path>_large.
 let bound_key=ptr(slot+0x28);
 let use_bound=path.contains("/stills/unitcards/") && ca_path(bound_key).is_some_and(|name|{
  let name=name.replace('\\',"/").to_ascii_lowercase();name==path||name==format!("{path}_large")
 }) && find_entry(manager+0x10,bound_key).is_some();
 let key=if use_bound{bound_key}else{original_key};
 if use_bound&&source.reported.fetch_or(32,Ordering::Relaxed)&32==0{log!("CARD bound atlas selected path={path} key=0x{key:x}; original=0x{original_key:x}");}
 let Some(entry)=find_entry(manager+0x10,key) else{return};let texture=ptr(entry+8);
 let Some(descriptor)=read::<32>(entry+0x38) else{return};
 // Keep the engine's existing atlas descriptor. Its uploader uses this region;
 // never synthesize a full-atlas image or replace other UI resources.
 let edge=u32at(base+0x3f5a858);let total=u32at(base+0x3f5a7e8);
 let (actual_w,actual_h)=if original_cpu!=0{(u32at(original_cpu+8),u32at(original_cpu+12))}else{
  let Some(size)=region_source_size(&descriptor,edge,total)else{return};
  if source.reported.fetch_or(64,Ordering::Relaxed)&64==0{log!("CARD direct atlas fallback {path} canvas={}x{}",size.0,size.1);}size
 };
 if actual_w!=w||actual_h!=h{
  if path.contains("/stills/unitcards/")&&actual_w>0&&actual_h>0&&actual_w<=4096&&actual_h<=4096{
   if source.reported.fetch_or(16,Ordering::Relaxed)&16==0{
    let path=path.to_owned();std::thread::spawn(move||{
     let Some(entry)=PLAYERS.get().and_then(|m|m.get(&path))else{return};
     let target=Entry{first:OnceLock::new(),preserve_size:entry.preserve_size,asset:entry.asset.clone(),w:actual_w,h:actual_h,offset:(0,0),player:OnceLock::new(),reported:AtomicU32::new(0)};
     match target.load(){Ok(mut resized)=>{
      let need=actual_w as u64*actual_h as u64*4*resized.stream.count as u64;
      if need+2*1024*1024*1024<available_memory(){if let Err(e)=resized.warm_cache(){log!("CARD cache resize failed: {e}");entry.reported.fetch_and(!16,Ordering::Relaxed);return}}
      if let Some(lock)=entry.player.get(){if let Ok(mut old)=lock.lock(){*old=resized;diagnostic!("CARD actual UI canvas ready {path} {actual_w}x{actual_h}");}}
     },Err(e)=>log!("CARD UI resize failed {path}: {e}")}
     entry.reported.fetch_and(!16,Ordering::Relaxed);
    });
   }
  }else if source.reported.fetch_or(1,Ordering::Relaxed)&1==0{log!("PLAYBACK UI image size mismatch path={path} actual={actual_w}x{actual_h} expected={w}x{h}");}
  return
 }
 if texture==0||!valid_region(&descriptor,w,h,edge,total){
  if source.reported.fetch_or(2,Ordering::Relaxed)&2==0{log!("PLAYBACK invalid UI region path={path} descriptor={descriptor:02x?} source={w}x{h} edge={edge} total={total}");}return
 }
 if (u32at(entry+0x38)!=w||u32at(entry+0x3c)!=h)&&source.reported.fetch_or(4,Ordering::Relaxed)&4==0{diagnostic!("PLAYBACK atlas region accepted path={path} atlas={}x{} source={w}x{h}",u32at(entry+0x38),u32at(entry+0x3c));}

 if read::<8>(base+0x123de80)!=Some([0x48,0x89,0x5c,0x24,0x10,0x57,0x48,0x83]){return}
 let image={
  let Ok(mut p)=player.try_lock() else{return};
  if path.contains("/stills/unitcards/"){
   // Campaign cards can be drawn before their selection state exists.
   // Still upload animation frame zero instead of exposing the PNG carrier.
   let selected=card_selection(component).unwrap_or(false);
   if let Err(e)=p.select_card(selected){log!("CARD selection reset failed: {e}");return}
  }
  match p.next_image(Instant::now()){
   Ok(Some(image))=>image,
   Ok(None)=>{if path.contains("/stills/unitcards/"){match p.retained_image(){Some(image)=>image,None=>return}}else{return}},
   Err(e)=>{p.stopped=true;log!("PLAYBACK stopped decode error {e}");return}
  }
 };
 // The inspected upload path consumes CPU pixels inside the call. Both image
 // objects and both backing allocations remain allocated for the process lifetime.
 let update:unsafe extern "C" fn(usize,usize)=std::mem::transmute(base+0x123de80);
 let prior=ANIMATION_UPLOAD.with(|v|v.replace(true));
 update(entry,image);
 ANIMATION_UPLOAD.with(|v|v.set(prior));
 if let Ok(p)=player.try_lock(){if p.updates==1||p.updates%100==0{diagnostic!("PLAYBACK upload returned entry=0x{entry:x} texture=0x{texture:x} tid={tid} updates={}",p.updates);}}
 if find_entry(manager+0x10,key)!=Some(entry)||ptr(entry+8)!=texture{
  if let Ok(mut p)=player.try_lock(){p.stopped=true;}record("PLAYBACK stopped: resource identity changed");
 }
}
#[cfg(test)]mod tests{
 use super::*;
 fn fixture()->Player{
  let mut bytes=Vec::new();
  {
   let mut encoder=png::Encoder::new(&mut bytes,4,4);
   encoder.set_color(png::ColorType::Rgba);encoder.set_depth(png::BitDepth::Eight);
   encoder.set_animated(203,0).unwrap();encoder.set_frame_delay(27,1000).unwrap();
   let mut writer=encoder.write_header().unwrap();
   for i in 0..203u32{let mut rgba=vec![0u8;4*4*4];for pixel in rgba.chunks_exact_mut(4){pixel.copy_from_slice(&[i as u8,(i/2) as u8,200,128]);}writer.write_image_data(&rgba).unwrap();}
   writer.finish().unwrap();
  }
  let mut stream=Stream::new(bytes.into()).unwrap();let delay=stream.next().unwrap().unwrap();
  Player{preserve_size:false,cache:None,card_selected:None,card_done:false,stream,buffers:[make_buffer(4,4),make_buffer(4,4)],next_buffer:0,offset:(0,0),due:None,seen:None,delay,loops:0,updates:0,stopped:false}
 }
 #[test]fn cached_frames_match_streaming(){
  let mut cached=fixture();cached.warm_cache().unwrap();let mut original=fixture();
  assert_eq!(cached.cache.as_ref().unwrap().frames.len(),203);
  for i in 0..203usize{
   assert_eq!(&cached.cache.as_ref().unwrap().frames[i][..],&original.stream.canvas[..]);
   if i<202{let a=cached.advance().unwrap();let b=original.stream.next().unwrap();assert_eq!(a,b);}
  }
  assert!(cached.advance().unwrap().is_none());cached.rewind().unwrap();assert!(cached.advance().unwrap().is_some());
  assert_eq!(cached.stream.index,1);
 }
 #[test]fn timing_and_pause(){
  let mut p=fixture();let now=Instant::now();assert!(p.next_image(now).unwrap().is_some());assert_eq!(p.stream.index,1);
  assert!(p.next_image(now+Duration::from_millis(10)).unwrap().is_none());
  assert!(p.next_image(now+Duration::from_millis(40)).unwrap().is_some());assert_eq!(p.stream.index,2);
  assert!(p.next_image(now+Duration::from_secs(1)).unwrap().is_some());assert_eq!(p.stream.index,1);
 }
 #[test]fn bounded_buffers_and_loop(){
  let mut p=fixture();let pointers=[p.buffers[0].pixels.as_ptr(),p.buffers[1].pixels.as_ptr()];let start=Instant::now();
  for ms in (0..6200).step_by(20){p.next_image(start+Duration::from_millis(ms)).unwrap();}
  assert!(p.loops>=1);assert_eq!(p.buffers[0].pixels.as_ptr(),pointers[0]);assert_eq!(p.buffers[1].pixels.as_ptr(),pointers[1]);
  assert!(p.updates>200);
 }
}

#[cfg(test)]mod resize_tests{use super::*;
  #[test]fn portrait_fit(){let src=vec![255;2*4*4];let mut dst=vec![0;8*8*4];fit_rgba(&src,2,4,&mut dst,8,8,true);for y in 0..8{for x in 0..8{assert_eq!(dst[(y*8+x)*4+3],if (2..6).contains(&y)&&(3..5).contains(&x){255}else{0});}}}
  #[test]fn transparent_edge(){let src=[255,0,0,0,0,0,255,255];let mut dst=vec![0;4];fit_rgba(&src,2,1,&mut dst,1,1,true);assert_eq!(dst,[0,0,255,128]);}
  #[test]fn small_source_preserves_every_pixel(){let src=[12,34,56,0,78,90,12,127,34,56,78,255,90,12,34,19];let mut dst=vec![255;5*5*4];fit_rgba(&src,2,2,&mut dst,5,5,true);for y in 0..5{for x in 0..5{let i=(y*5+x)*4;if (1..3).contains(&y)&&(1..3).contains(&x){let s=((y-1)*2+x-1)*4;assert_eq!(&dst[i..i+4],&src[s..s+4]);}else{assert_eq!(&dst[i..i+4],&[0,0,0,0]);}}}}
 #[test]fn cards_keep_existing_scale(){let src=vec![255;2*4*4];let mut dst=vec![0;8*8*4];fit_rgba(&src,2,4,&mut dst,8,8,false);for y in 0..8{for x in 0..8{assert_eq!(dst[(y*8+x)*4+3],if (2..6).contains(&x){255}else{0});}}}
 #[test]fn exact_size(){let src=vec![123;24];let mut dst=vec![0;24];fit_rgba(&src,2,3,&mut dst,2,3,true);assert_eq!(src,dst);}
}
#[cfg(test)]mod card_tests{use super::*;
 fn player()->Player{
  let mut bytes=Vec::new();{let mut enc=png::Encoder::new(&mut bytes,1,1);enc.set_color(png::ColorType::Rgba);enc.set_depth(png::BitDepth::Eight);enc.set_animated(2,0).unwrap();enc.set_frame_delay(1,10).unwrap();let mut w=enc.write_header().unwrap();w.write_image_data(&[10,20,30,255]).unwrap();w.write_image_data(&[80,90,100,255]).unwrap();w.finish().unwrap();}
  let mut stream=Stream::new(bytes.into()).unwrap();let delay=stream.next().unwrap().unwrap();Player{preserve_size:false,cache:None,card_selected:None,card_done:false,stream,buffers:[make_buffer(1,1),make_buffer(1,1)],next_buffer:0,offset:(0,0),due:None,seen:None,delay,loops:0,updates:0,stopped:false}
 }
 #[test]fn one_shot_returns_to_first_and_reselect_restarts(){let mut p=player();p.warm_cache().unwrap();let t=Instant::now();p.select_card(false).unwrap();assert!(p.next_image(t).unwrap().is_some());assert!(p.next_image(t+Duration::from_secs(2)).unwrap().is_none());assert_eq!(p.stream.index,1);p.select_card(true).unwrap();p.next_image(t).unwrap();p.next_image(t+Duration::from_millis(110)).unwrap();assert_eq!(p.stream.index,2);p.next_image(t+Duration::from_millis(220)).unwrap();assert!(p.card_done);assert_eq!(p.stream.index,1);assert!(!p.stopped);assert!(p.next_image(t+Duration::from_secs(1)).unwrap().is_none());p.select_card(false).unwrap();p.next_image(t).unwrap();p.select_card(true).unwrap();p.next_image(t).unwrap();assert!(!p.card_done);assert_eq!(p.stream.index,1);}
 #[test]fn deselection_resets_mid_animation(){let mut p=player();let t=Instant::now();p.select_card(true).unwrap();p.next_image(t).unwrap();p.next_image(t+Duration::from_millis(110)).unwrap();assert_eq!(p.stream.index,2);p.select_card(false).unwrap();p.next_image(t+Duration::from_millis(120)).unwrap();assert_eq!(p.stream.index,1);}
}

#[cfg(test)]mod retained_card_tests{
 use super::*;
 #[test]fn retained_frame_does_not_advance_or_copy(){
  let mut pixels=std::io::Cursor::new(Vec::new());
  {let mut enc=png::Encoder::new(&mut pixels,1,1);enc.set_color(png::ColorType::Rgba);enc.set_depth(png::BitDepth::Eight);enc.set_animated(2,0).unwrap();let mut w=enc.write_header().unwrap();w.write_image_data(&[255,0,0,255]).unwrap();w.write_image_data(&[0,255,0,255]).unwrap();}
  let stream=Stream::new(pixels.into_inner().into()).unwrap();
  let mut p=Player{preserve_size:false,cache:None,card_selected:None,card_done:false,stream,buffers:[make_buffer(1,1),make_buffer(1,1)],next_buffer:0,offset:(0,0),due:None,seen:None,delay:0.1,loops:0,updates:0,stopped:false};
  assert_eq!(p.retained_image(),None);p.select_card(false).unwrap();let now=Instant::now();let first=p.next_image(now).unwrap().unwrap();let count=p.updates;let index=p.stream.index;
  for _ in 0..100{assert_eq!(p.retained_image(),Some(first));}
  assert_eq!(p.updates,count);assert_eq!(p.stream.index,index);assert!(p.next_image(now+Duration::from_secs(1)).unwrap().is_none());assert_eq!(p.retained_image(),Some(first));
 }
}

#[cfg(test)]mod initial_frame_tests{
 use super::*;
 #[test]fn initial_frame_stays_independent_of_animation_progress(){
  let mut bytes=Vec::new();{let mut e=png::Encoder::new(&mut bytes,1,1);e.set_color(png::ColorType::Rgba);e.set_depth(png::BitDepth::Eight);e.set_animated(2,0).unwrap();let mut w=e.write_header().unwrap();w.write_image_data(&[10,20,30,255]).unwrap();w.write_image_data(&[90,80,70,255]).unwrap();}
  let file=std::env::temp_dir().join(format!("vg_initial_frame_{}.png",std::process::id()));std::fs::write(&file,&bytes).unwrap();
  let entry=Entry{first:OnceLock::new(),preserve_size:false,asset:super::super::runtime_assets::Asset{pack:file.clone(),offset:0,size:bytes.len() as u64,compressed:false},w:1,h:1,offset:(0,0),player:OnceLock::new(),reported:AtomicU32::new(0)};
  assert_eq!(entry.initial_frame().unwrap().pixels,[10,20,30,255]);let first=entry.initial_frame().unwrap().pixels.as_ptr();
  let mut player=entry.load().unwrap();player.select_card(true).unwrap();let now=Instant::now();player.next_image(now).unwrap();player.advance().unwrap();assert_eq!(player.stream.index,2);
  assert_eq!(entry.initial_frame().unwrap().pixels,[10,20,30,255]);assert_eq!(entry.initial_frame().unwrap().pixels.as_ptr(),first);std::fs::remove_file(file).unwrap();
 }
}
