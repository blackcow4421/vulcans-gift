//! Native APNG portrait playback with verified existing-resource updates.
#![cfg(windows)]
use std::{cell::Cell,ffi::c_void,sync::{OnceLock,atomic::{AtomicUsize,Ordering}},io::Write};
use retour::GenericDetour;
mod freeze;
mod resource;
mod apng_decode;
mod animation_decode;
mod playback;
mod runtime_assets;
mod core_bridge;
const TRACE:bool=false;
static BASE:AtomicUsize=AtomicUsize::new(0);
static SELF:AtomicUsize=AtomicUsize::new(0);
static EVENTS:AtomicUsize=AtomicUsize::new(0);
static UPLOAD_EVENTS:AtomicUsize=AtomicUsize::new(0);
static LOG:OnceLock<std::path::PathBuf>=OnceLock::new();
type SetPath=unsafe extern "C" fn(usize,usize,u32,u8)->u8;
type Assign=unsafe extern "C" fn(usize,usize,u32,usize,usize,u8,u8,u8)->usize;
type Upload=unsafe extern "C" fn(usize,usize,usize,usize)->usize;
static PATH_HOOK:OnceLock<GenericDetour<SetPath>>=OnceLock::new();
static ASSIGN_HOOK:OnceLock<GenericDetour<Assign>>=OnceLock::new();
static UPLOAD_HOOK:OnceLock<GenericDetour<Upload>>=OnceLock::new();
thread_local!{static ACTIVE_PATH:std::cell::RefCell<String>=const{std::cell::RefCell::new(String::new())};static TARGET:Cell<bool>=const{Cell::new(false)};static WRITE_TARGET:Cell<bool>=const{Cell::new(false)};}
extern "system" {
 fn GetModuleHandleW(name:*const u16)->*mut c_void;
 fn GetModuleFileNameW(module:*mut c_void,path:*mut u16,n:u32)->u32;
 fn GetCurrentProcess()->*mut c_void;
 fn ReadProcessMemory(process:*mut c_void,address:*const c_void,data:*mut c_void,n:usize,got:*mut usize)->i32;
 fn GetCurrentThreadId()->u32;
 fn DisableThreadLibraryCalls(module:*mut c_void)->i32;
}
pub fn record(s:&str){if let Some(p)=LOG.get(){if let Ok(mut f)=std::fs::OpenOptions::new().create(true).append(true).open(p){let _=writeln!(f,"{s}");}}}
#[macro_export] macro_rules! log {($($t:tt)*)=>{$crate::record(&format!($($t)*))};}
fn read<const N:usize>(address:usize)->Option<[u8;N]>{
 if address==0{return None}let mut out=[0;N];let mut n=0;
 let ok=unsafe{ReadProcessMemory(GetCurrentProcess(),address as _,out.as_mut_ptr() as _,N,&mut n)};
 (ok!=0 && n==N).then_some(out)
}
fn ptr(a:usize)->usize {read::<8>(a).map(usize::from_le_bytes).unwrap_or(0)}
fn u32at(a:usize)->u32 {read::<4>(a).map(u32::from_le_bytes).unwrap_or(0)}
fn code_address(a:usize)->String{
 let b=BASE.load(Ordering::Relaxed);if a>=b && a<b+0x4836000{format!("exe+0x{:x}",a-b)}else{format!("0x{a:x}")}
}
fn ca_path(s:usize)->Option<String>{
 let bits=ptr(s+8);let inline=bits>>60==8;
 let len=if inline{(bits>>56)&15}else{u32at(s) as usize};
 if len==0||len>1024{return None}
 let start=if inline{s}else{bits};let mut bytes=vec![0u8;len];let mut got=0;
 if unsafe{ReadProcessMemory(GetCurrentProcess(),start as _,bytes.as_mut_ptr() as _,len,&mut got)}==0||got!=len{return None}
 String::from_utf8(bytes).ok()
}
fn trace_assign(phase:&str,slot:usize,component:usize,index:u32,cpu:usize){
 let owner=ptr(slot+0x38);let owner_vtable=ptr(owner);let getter=ptr(owner_vtable+0x220);
 let cpu_vtable=ptr(cpu);let pixels=ptr(cpu+0x18);
 log!("ASSIGN phase={phase} tid={} index={index} slot=0x{slot:x} component=0x{component:x} cpu=0x{cpu:x} cpu_vtable={} width={} height={} pixels=0x{pixels:x} image_ref=0x{:x} owner=0x{owner:x} owner_vtable={} owner_getter_220={} getter_bytes={:02x?}",unsafe{GetCurrentThreadId()},code_address(cpu_vtable),u32at(cpu+8),u32at(cpu+12),ptr(slot+8),code_address(owner_vtable),code_address(getter),read::<24>(getter));
 // Snapshot only object fields. Do not call unknown virtual functions as probes.
 if let Some(bytes)=read::<96>(slot){log!("SLOT_BYTES phase={phase} {bytes:02x?}");}
 if u32at(cpu+8)==1200 && u32at(cpu+12)==1200{
  for (x,y) in [(600usize,300usize),(600,500),(550,800),(700,1000)]{
   log!("PIXEL phase={phase} x={x} y={y} bytes={:02x?}",read::<4>(pixels+(y*1200+x)*4));
  }
 }
 // The getter observed in the previous run is a leaf `lea rax,[rcx+0x180];ret`.
 // Interpret only verified leaf instructions; never execute speculative getters.
 if read::<8>(getter)==Some([0x48,0x8d,0x81,0x80,0x01,0x00,0x00,0xc3]){
  let context=owner+0x180;let context_vtable=ptr(context);
  let render_getter=ptr(context_vtable+0x190);let code=read::<24>(render_getter);
  log!("CONTEXT phase={phase} context=0x{context:x} vtable={} render_getter_190={} bytes={code:02x?}",code_address(context_vtable),code_address(render_getter));
  if let Some(code)=code{
   let render=if code[..3]==[0x48,0x8b,0x81] && code[7]==0xc3{
    let delta=i32::from_le_bytes(code[3..7].try_into().unwrap()) as isize;ptr(context.wrapping_add_signed(delta))
   }else if code[..3]==[0x48,0x8b,0x41] && code[4]==0xc3{ptr(context+code[3] as usize)}
   else if code[..3]==[0x48,0x8d,0x81] && code[7]==0xc3{
    let delta=i32::from_le_bytes(code[3..7].try_into().unwrap()) as isize;context.wrapping_add_signed(delta)
   }else{0};
   if render!=0{
    let vt=ptr(render);let create=ptr(vt+0x20);let update=ptr(vt+0x38);
    log!("RENDER phase={phase} renderer=0x{render:x} vtable={} slot20={} slot38={} update_bytes={:02x?}",code_address(vt),code_address(create),code_address(update),read::<32>(update));
   }
  }
 }
}
unsafe extern "C" fn set_path(component:usize,path:usize,index:u32,flag:u8)->u8{
 let text=ca_path(path).unwrap_or_default();
 let normalized=text.replace('\\',"/").to_ascii_lowercase();
 let previous_path=ACTIVE_PATH.with(|p|p.replace(normalized.clone()));
 let old_write=WRITE_TARGET.with(|t|{let old=t.get();t.set(playback::contains(&normalized));old});
 let match_target=text.contains("water_strategist_face_11")||text.contains("astral_apng_test/");
 let prior=TARGET.with(|t|{let old=t.get();t.set(old||match_target);old});
 if TRACE && match_target && EVENTS.load(Ordering::Relaxed)<24{log!("PATH tid={} component=0x{component:x} index={index} path={text}",GetCurrentThreadId());}
 let result=PATH_HOOK.get().unwrap().call(component,path,index,flag);
 ACTIVE_PATH.with(|p|{p.replace(previous_path);});TARGET.with(|t|t.set(prior));WRITE_TARGET.with(|t|t.set(old_write));result
}
unsafe extern "C" fn assign(slot:usize,component:usize,index:u32,cpu:usize,path:usize,a:u8,b:u8,c:u8)->usize{
 let trace=TRACE && TARGET.with(Cell::get)&&EVENTS.fetch_add(1,Ordering::Relaxed)<24;
 if trace{trace_assign("before",slot,component,index,cpu);}
 let result=ASSIGN_HOOK.get().unwrap().call(slot,component,index,cpu,path,a,b,c);
 if trace{trace_assign("after",slot,component,index,cpu);}
 if WRITE_TARGET.with(Cell::get){let active=ACTIVE_PATH.with(|p|p.borrow().clone());playback::tick(slot,cpu,&active);}
 result
}
unsafe extern "C" fn upload(texture:usize,descriptor:usize,cpu:usize,rect:usize)->usize{
 let w=u32at(cpu+8);let h=u32at(cpu+12);
 let trace=w>=512 && h>=512 && w<=8192 && h<=8192 && UPLOAD_EVENTS.fetch_add(1,Ordering::Relaxed)<32;
 if trace{
  log!("UPLOAD before tid={} texture=0x{texture:x} descriptor=0x{descriptor:x} cpu=0x{cpu:x} width={w} height={h} pixels=0x{:x} rect=0x{rect:x} descriptor_bytes={:02x?}",GetCurrentThreadId(),ptr(cpu+0x18),read::<80>(descriptor));
 }
 let result=UPLOAD_HOOK.get().unwrap().call(texture,descriptor,cpu,rect);
 if trace{log!("UPLOAD after tid={} cpu=0x{cpu:x} result=0x{result:x}",GetCurrentThreadId());}
 result
}
fn bootstrap(){unsafe{
 let mut name=[0u16;32768];let n=GetModuleFileNameW(SELF.load(Ordering::Relaxed) as _,name.as_mut_ptr(),name.len() as u32) as usize;
 if n==0||n>=name.len(){return}let path=std::path::PathBuf::from(String::from_utf16_lossy(&name[..n]));let _=LOG.set(path.with_file_name("VulcansGift.log"));
 let base=GetModuleHandleW(std::ptr::null()) as usize;BASE.store(base,Ordering::Relaxed);
 let nt=base+u32at(base+0x3c) as usize;
 if u32at(nt+8)!=0x69ce4c84||u32at(nt+24+0x38)!=0x4836000{record("REFUSED game fingerprint mismatch");return}
 if let Err(e)=core_bridge::ensure(&path){log!("REFUSED core bridge: {e}");return}
 // TKMM verifies the selected local version via this file; the official core
 // retains its own original log and inventory in its unchanged version folder.
 let manager_log=path.with_file_name("script_extender.log");
 let _=std::fs::write(&manager_log,"bootstrap complete: official TKMM 0.46.0 core ready; Vulcan's Gift extension starting\n");
 if let Err(e)=playback::prepare_runtime(){log!("REFUSED runtime discovery: {e}");return}
 if read::<8>(base+0x63f940)!=Some([0x48,0x89,0x5c,0x24,0x08,0x48,0x89,0x6c])||read::<8>(base+0x640190)!=Some([0x48,0x89,0x5c,0x24,0x18,0x55,0x57,0x41]){record("REFUSED image anchor mismatch or another hook present");return}
 let p:SetPath=std::mem::transmute(base+0x63f940);let a:Assign=std::mem::transmute(base+0x640190);
 let ph=match GenericDetour::new(p,set_path){Ok(d)=>d,Err(e)=>{log!("REFUSED path detour {e}");return}};
 let ah=match GenericDetour::new(a,assign){Ok(d)=>d,Err(e)=>{log!("REFUSED assign detour {e}");return}};
 let _=PATH_HOOK.set(ph);let _=ASSIGN_HOOK.set(ah);
 let enabled=freeze::with_threads_frozen(base+0x63f940,0x6401c0-0x63f940,||{
  // All detours are published before any jump is enabled.
  ASSIGN_HOOK.get().unwrap().enable()?;
  if let Err(e)=PATH_HOOK.get().unwrap().enable(){let _=ASSIGN_HOOK.get().unwrap().disable();return Err(e)}Ok::<(),retour::Error>(())
 });
 match enabled{Ok(Ok(()))=>{},Ok(Err(e))=>{log!("REFUSED enable {e}");return},Err(e)=>{log!("REFUSED freeze {e}");return}}
 if TRACE && read::<8>(base+0x1269880)==Some([0x48,0x89,0x5c,0x24,0x18,0x48,0x89,0x6c]){
  let target:Upload=std::mem::transmute(base+0x1269880);
  match GenericDetour::new(target,upload){
   Ok(d)=>{
    let _=UPLOAD_HOOK.set(d);
    match freeze::with_threads_frozen(base+0x1269880,32,||UPLOAD_HOOK.get().unwrap().enable()){
     Ok(Ok(()))=>record("UPLOAD observation installed; original four arguments and return preserved"),
     _=>record("UPLOAD observation unavailable; image assignment observation remains active")
    }
   },Err(e)=>log!("UPLOAD detour unavailable {e}")
  }
 }
 record("READY native APNG hooks installed; source image buffers unchanged; TKMM extender retained");
}}
#[no_mangle]
pub extern "system" fn DllMain(module:*mut c_void,reason:u32,_reserved:*mut c_void)->i32{
 if reason==1{SELF.store(module as usize,Ordering::Relaxed);unsafe{DisableThreadLibraryCalls(module)};std::thread::spawn(bootstrap);}1
}
