//! Native APNG portrait playback with verified existing-resource updates.
#![cfg(windows)]
use std::{cell::Cell,ffi::c_void,sync::{OnceLock,atomic::{AtomicUsize,Ordering}},io::Write};
use retour::GenericDetour;
mod freeze;
mod resource;
mod apng_decode;
mod animation_decode;
mod playback;
mod runtime_assets;
mod core_bridge;
static BASE:AtomicUsize=AtomicUsize::new(0);
static SELF:AtomicUsize=AtomicUsize::new(0);
static LOG:OnceLock<std::path::PathBuf>=OnceLock::new();
type SetPath=unsafe extern "C" fn(usize,usize,u32,u8)->u8;
type Upload=unsafe extern "C" fn(usize,usize,usize,usize)->usize;
static UPLOAD_HOOK:OnceLock<GenericDetour<Upload>>=OnceLock::new();
thread_local!{static ANIMATION_UPLOAD:Cell<bool>=const{Cell::new(false)};}
static INITIAL_UPLOAD_LOGGED:OnceLock<std::sync::Mutex<std::collections::HashSet<String>>>=OnceLock::new();
type Assign=unsafe extern "C" fn(usize,usize,u32,usize,usize,u8,u8,u8)->usize;
static PATH_HOOK:OnceLock<GenericDetour<SetPath>>=OnceLock::new();
static ASSIGN_HOOK:OnceLock<GenericDetour<Assign>>=OnceLock::new();
thread_local!{static ACTIVE_PATH:std::cell::RefCell<String>=const{std::cell::RefCell::new(String::new())};static WRITE_TARGET:Cell<bool>=const{Cell::new(false)};}
thread_local!{static PENDING_CARD:Cell<Option<(usize,usize)>>=const{Cell::new(None)};}
thread_local!{static ACTIVE_COMPONENT:Cell<usize>=const{Cell::new(0)};}
extern "system" {
 fn GetModuleHandleW(name:*const u16)->*mut c_void;
 fn GetModuleFileNameW(module:*mut c_void,path:*mut u16,n:u32)->u32;
 fn GetCurrentProcess()->*mut c_void;
 fn ReadProcessMemory(process:*mut c_void,address:*const c_void,data:*mut c_void,n:usize,got:*mut usize)->i32;
 fn GetCurrentThreadId()->u32;
 fn DisableThreadLibraryCalls(module:*mut c_void)->i32;
}
pub fn record(s:&str){if let Some(p)=LOG.get(){if let Ok(mut f)=std::fs::OpenOptions::new().create(true).append(true).open(p){let _=writeln!(f,"{s}");}}}
#[macro_export] macro_rules! diagnostic {($($t:tt)*)=>{if cfg!(debug_assertions){$crate::record(&format!($($t)*))}};}
#[macro_export] macro_rules! log {($($t:tt)*)=>{$crate::record(&format!($($t)*))};}
fn read<const N:usize>(address:usize)->Option<[u8;N]>{
 if address==0{return None}let mut out=[0;N];let mut n=0;
 let ok=unsafe{ReadProcessMemory(GetCurrentProcess(),address as _,out.as_mut_ptr() as _,N,&mut n)};
 (ok!=0 && n==N).then_some(out)
}
fn ptr(a:usize)->usize {read::<8>(a).map(usize::from_le_bytes).unwrap_or(0)}
fn u32at(a:usize)->u32 {read::<4>(a).map(u32::from_le_bytes).unwrap_or(0)}
fn ca_path(s:usize)->Option<String>{
 let bits=ptr(s+8);let inline=bits>>60==8;
 let len=if inline{(bits>>56)&15}else{u32at(s) as usize};
 if len==0||len>1024{return None}
 let start=if inline{s}else{bits};let mut bytes=vec![0u8;len];let mut got=0;
 if unsafe{ReadProcessMemory(GetCurrentProcess(),start as _,bytes.as_mut_ptr() as _,len,&mut got)}==0||got!=len{return None}
 String::from_utf8(bytes).ok()
}
unsafe extern "C" fn set_path(component:usize,path:usize,index:u32,flag:u8)->u8{
 let previous_component=ACTIVE_COMPONENT.with(|c|c.replace(component));
 let text=ca_path(path).unwrap_or_default();
 let normalized=text.replace('\\',"/").to_ascii_lowercase();
 let previous_path=ACTIVE_PATH.with(|p|p.replace(normalized.clone()));
 let old_write=WRITE_TARGET.with(|t|{let old=t.get();t.set(playback::contains(&normalized));old});
 let old_pending=PENDING_CARD.with(|p|p.take());
 let result=PATH_HOOK.get().unwrap().call(component,path,index,flag);
 // Finish the original image assignment before touching its atlas region.
 let pending=PENDING_CARD.with(|p|p.take());
 if let Some((slot,cpu))=pending{
  playback::tick(slot,cpu,&normalized,component);
 }else if playback::defer_card_upload(&normalized){
  // Unchanged paths can skip Assign. Resolve the live atlas region instead
  // of depending on a CPU image observed during a previous selection.
  let count=u32at(component+0x144);let slots=ptr(component+0x148);
  if index<count&&index<64{
   let slot=ptr(slots+index as usize*8);
   if ca_path(ptr(slot+0x50)).is_some_and(|name|name.replace('\\',"/").to_ascii_lowercase()==normalized){playback::tick(slot,0,&normalized,component);}
  }
 }
 PENDING_CARD.with(|p|p.set(old_pending));
 ACTIVE_PATH.with(|p|{p.replace(previous_path);});WRITE_TARGET.with(|t|t.set(old_write));ACTIVE_COMPONENT.with(|c|c.set(previous_component));result
}
// The engine's inline CA string representation: empty, no owned allocation.
static EMPTY_IMAGE_NAME:[u64;2]=[0,0x8000000000000000];
fn summary_ancestor(names:&[String])->bool{
 names.iter().any(|name|name=="general_info_panel_parent")
  &&!names.iter().any(|name|name=="character_details"||name=="advice_interface")
}
fn is_summary_component(mut component:usize)->bool{
 let mut names=Vec::new();
 for _ in 0..32{
  if component==0{break}
  if let Some(name)=ca_path(ptr(component+0xf0)){names.push(name);}
  let parent=ptr(component+0x118);if parent==component{break}component=parent;
 }
 summary_ancestor(&names)
}
unsafe extern "C" fn assign(slot:usize,component:usize,index:u32,cpu:usize,path:usize,a:u8,b:u8,c:u8)->usize{
 let active=ACTIVE_PATH.with(|p|p.borrow().clone());
 let source=if playback::contains(&active){Some(active)}else{ca_path(path).map(|name|name.replace('\\',"/").to_ascii_lowercase()).filter(|name|playback::contains(name))};
 if let Some(source)=source.filter(|name|!name.contains("/stills/unitcards/")){
  if is_summary_component(component)&&ptr(cpu)==BASE.load(Ordering::Relaxed)+0x32670e0{
   if let Some(first)=playback::initial_upload_image(&source,u32at(cpu+8),u32at(cpu+12)){
    // Empty resource name + private image requests the engine's per-component
    // generated resource key, isolating the summary from the animated atlas.
    let result=ASSIGN_HOOK.get().unwrap().call(slot,component,index,first,EMPTY_IMAGE_NAME.as_ptr() as usize,a,1,c);
    let key=ptr(slot+0x50);
    let token=format!("summary/{component:x}/{index}/{source}");
    if let Ok(mut seen)=INITIAL_UPLOAD_LOGGED.get_or_init(||std::sync::Mutex::new(std::collections::HashSet::new())).lock(){if seen.insert(token){log!("SUMMARY static resource path={source} key=0x{key:x}");}}
    return result
   }
  }
 }
 let result=ASSIGN_HOOK.get().unwrap().call(slot,component,index,cpu,path,a,b,c);

 if WRITE_TARGET.with(Cell::get){let active=ACTIVE_PATH.with(|p|p.borrow().clone());if playback::defer_card_upload(&active){PENDING_CARD.with(|p|p.set(Some((slot,cpu))));}
  else{playback::tick(slot,cpu,&active,ACTIVE_COMPONENT.with(Cell::get));}}
 result
}
fn native_card_upload_path(name:&str)->Option<String>{
 let path=name.replace('\\',"/").to_ascii_lowercase();
 if playback::defer_card_upload(&path){return Some(path)}
 let original=path.strip_suffix("_large")?;
 playback::defer_card_upload(original).then(||original.to_owned())
}
unsafe extern "C" fn upload(texture:usize,descriptor:usize,cpu:usize,rect:usize)->usize{
 let replacement=if !ANIMATION_UPLOAD.with(Cell::get)&&ptr(cpu)==BASE.load(Ordering::Relaxed)+0x32670e0{
  ca_path(texture).and_then(|name|native_card_upload_path(&name)).and_then(|path|{
   let w=u32at(cpu+8);let h=u32at(cpu+12);
   let image=playback::initial_upload_image(&path,w,h)?;
   if let Ok(mut seen)=INITIAL_UPLOAD_LOGGED.get_or_init(||std::sync::Mutex::new(std::collections::HashSet::new())).lock(){if seen.insert(path.clone()){log!("CARD initial GPU upload replaced before PNG path={path} canvas={w}x{h}");}}
   Some(image)
  })
 }else{None};
 UPLOAD_HOOK.get().unwrap().call(texture,descriptor,replacement.unwrap_or(cpu),rect)
}
fn bootstrap(){unsafe{
 let mut name=[0u16;32768];let n=GetModuleFileNameW(SELF.load(Ordering::Relaxed) as _,name.as_mut_ptr(),name.len() as u32) as usize;
 if n==0||n>=name.len(){return}let path=std::path::PathBuf::from(String::from_utf16_lossy(&name[..n]));let _=LOG.set(path.with_file_name("VulcansGift.log"));
 let base=GetModuleHandleW(std::ptr::null()) as usize;BASE.store(base,Ordering::Relaxed);
 let nt=base+u32at(base+0x3c) as usize;
 if u32at(nt+8)!=0x69ce4c84||u32at(nt+24+0x38)!=0x4836000{record("REFUSED game fingerprint mismatch");return}
 if let Err(e)=core_bridge::ensure(&path){log!("REFUSED core bridge: {e}");return}
 // TKMM verifies the selected local version via this file; the official core
 // retains its own original log and inventory in its unchanged version folder.
 let manager_log=path.with_file_name("script_extender.log");
 let _=std::fs::write(&manager_log,"bootstrap complete: official TKMM 0.46.0 core ready; Vulcan's Gift extension starting\n");
 if let Err(e)=playback::prepare_runtime(){log!("REFUSED runtime discovery: {e}");return}
 if read::<8>(base+0x63f940)!=Some([0x48,0x89,0x5c,0x24,0x08,0x48,0x89,0x6c])||read::<8>(base+0x640190)!=Some([0x48,0x89,0x5c,0x24,0x18,0x55,0x57,0x41]){record("REFUSED image anchor mismatch or another hook present");return}
 if read::<8>(base+0x1269880)!=Some([0x48,0x89,0x5c,0x24,0x18,0x48,0x89,0x6c]){record("REFUSED initial upload fingerprint mismatch");return}
 let uh=match GenericDetour::new(std::mem::transmute::<usize,Upload>(base+0x1269880),upload){Ok(d)=>d,Err(e)=>{log!("REFUSED upload detour {e}");return}};
 let _=UPLOAD_HOOK.set(uh);
 let enabled_upload=freeze::with_threads_frozen(base+0x1269880,32,||UPLOAD_HOOK.get().unwrap().enable());
 if !matches!(enabled_upload,Ok(Ok(()))){record("REFUSED initial upload hook enable");return}
 let p:SetPath=std::mem::transmute(base+0x63f940);let a:Assign=std::mem::transmute(base+0x640190);
 let ph=match GenericDetour::new(p,set_path){Ok(d)=>d,Err(e)=>{log!("REFUSED path detour {e}");return}};
 let ah=match GenericDetour::new(a,assign){Ok(d)=>d,Err(e)=>{log!("REFUSED assign detour {e}");return}};
 let _=PATH_HOOK.set(ph);let _=ASSIGN_HOOK.set(ah);
 let enabled=freeze::with_threads_frozen(base+0x63f940,0x6401c0-0x63f940,||{
  // All detours are published before any jump is enabled.
  ASSIGN_HOOK.get().unwrap().enable()?;
  if let Err(e)=PATH_HOOK.get().unwrap().enable(){let _=ASSIGN_HOOK.get().unwrap().disable();return Err(e)}Ok::<(),retour::Error>(())
 });
 match enabled{Ok(Ok(()))=>{},Ok(Err(e))=>{log!("REFUSED enable {e}");return},Err(e)=>{log!("REFUSED freeze {e}");return}}
 record("READY native APNG hooks installed; source image buffers unchanged; TKMM extender retained");
}}
#[no_mangle]
pub extern "system" fn DllMain(module:*mut c_void,reason:u32,_reserved:*mut c_void)->i32{
 if reason==1{SELF.store(module as usize,Ordering::Relaxed);unsafe{DisableThreadLibraryCalls(module)};std::thread::spawn(bootstrap);}1
}

#[cfg(test)]mod summary_scope_tests{
 use super::*;
 fn names(values:&[&str])->Vec<String>{values.iter().map(|s|s.to_string()).collect()}
 #[test]fn summary_only(){assert!(summary_ancestor(&names(&["face","character_display","unit_info_panel","general_info_panel_parent","root"])));assert!(!summary_ancestor(&names(&["face","fullbody_character","character_details","root"])));assert!(!summary_ancestor(&names(&["unit_card_hero","units_panel","root"])));assert!(!summary_ancestor(&names(&["advisor_portrait_parent","advice_interface","root"])));}
}
