//! Native APNG portrait playback with verified existing-resource updates.
#![cfg(windows)]
use std::{cell::Cell,ffi::c_void,sync::{OnceLock,atomic::{AtomicUsize,Ordering}},io::Write};
use retour::GenericDetour;
mod freeze;
mod resource;
mod apng_decode;
mod animation_decode;
mod playback;
mod runtime_assets;
mod core_bridge;
static BASE:AtomicUsize=AtomicUsize::new(0);
static SELF:AtomicUsize=AtomicUsize::new(0);
static LOG:OnceLock<std::path::PathBuf>=OnceLock::new();
type SetPath=unsafe extern "C" fn(usize,usize,u32,u8)->u8;
type Assign=unsafe extern "C" fn(usize,usize,u32,usize,usize,u8,u8,u8)->usize;
static PATH_HOOK:OnceLock<GenericDetour<SetPath>>=OnceLock::new();
static ASSIGN_HOOK:OnceLock<GenericDetour<Assign>>=OnceLock::new();
thread_local!{static ACTIVE_PATH:std::cell::RefCell<String>=const{std::cell::RefCell::new(String::new())};static WRITE_TARGET:Cell<bool>=const{Cell::new(false)};}
thread_local!{static ACTIVE_COMPONENT:Cell<usize>=const{Cell::new(0)};}
extern "system" {
 fn GetModuleHandleW(name:*const u16)->*mut c_void;
 fn GetModuleFileNameW(module:*mut c_void,path:*mut u16,n:u32)->u32;
 fn GetCurrentProcess()->*mut c_void;
 fn ReadProcessMemory(process:*mut c_void,address:*const c_void,data:*mut c_void,n:usize,got:*mut usize)->i32;
 fn GetCurrentThreadId()->u32;
 fn DisableThreadLibraryCalls(module:*mut c_void)->i32;
}
pub fn record(s:&str){if let Some(p)=LOG.get(){if let Ok(mut f)=std::fs::OpenOptions::new().create(true).append(true).open(p){let _=writeln!(f,"{s}");}}}
#[macro_export] macro_rules! diagnostic {($($t:tt)*)=>{if cfg!(debug_assertions){$crate::record(&format!($($t)*))}};}
#[macro_export] macro_rules! log {($($t:tt)*)=>{$crate::record(&format!($($t)*))};}
fn read<const N:usize>(address:usize)->Option<[u8;N]>{
 if address==0{return None}let mut out=[0;N];let mut n=0;
 let ok=unsafe{ReadProcessMemory(GetCurrentProcess(),address as _,out.as_mut_ptr() as _,N,&mut n)};
 (ok!=0 && n==N).then_some(out)
}
fn ptr(a:usize)->usize {read::<8>(a).map(usize::from_le_bytes).unwrap_or(0)}
fn u32at(a:usize)->u32 {read::<4>(a).map(u32::from_le_bytes).unwrap_or(0)}
fn ca_path(s:usize)->Option<String>{
 let bits=ptr(s+8);let inline=bits>>60==8;
 let len=if inline{(bits>>56)&15}else{u32at(s) as usize};
 if len==0||len>1024{return None}
 let start=if inline{s}else{bits};let mut bytes=vec![0u8;len];let mut got=0;
 if unsafe{ReadProcessMemory(GetCurrentProcess(),start as _,bytes.as_mut_ptr() as _,len,&mut got)}==0||got!=len{return None}
 String::from_utf8(bytes).ok()
}
unsafe extern "C" fn set_path(component:usize,path:usize,index:u32,flag:u8)->u8{
 let previous_component=ACTIVE_COMPONENT.with(|c|c.replace(component));
 let text=ca_path(path).unwrap_or_default();
 let normalized=text.replace('\\',"/").to_ascii_lowercase();
 let previous_path=ACTIVE_PATH.with(|p|p.replace(normalized.clone()));
 let old_write=WRITE_TARGET.with(|t|{let old=t.get();t.set(playback::contains(&normalized));old});
 let result=PATH_HOOK.get().unwrap().call(component,path,index,flag);
 ACTIVE_PATH.with(|p|{p.replace(previous_path);});WRITE_TARGET.with(|t|t.set(old_write));ACTIVE_COMPONENT.with(|c|c.set(previous_component));result
}
unsafe extern "C" fn assign(slot:usize,component:usize,index:u32,cpu:usize,path:usize,a:u8,b:u8,c:u8)->usize{
 let result=ASSIGN_HOOK.get().unwrap().call(slot,component,index,cpu,path,a,b,c);
 if WRITE_TARGET.with(Cell::get){let active=ACTIVE_PATH.with(|p|p.borrow().clone());playback::tick(slot,cpu,&active,ACTIVE_COMPONENT.with(Cell::get));}
 result
}
fn bootstrap(){unsafe{
 let mut name=[0u16;32768];let n=GetModuleFileNameW(SELF.load(Ordering::Relaxed) as _,name.as_mut_ptr(),name.len() as u32) as usize;
 if n==0||n>=name.len(){return}let path=std::path::PathBuf::from(String::from_utf16_lossy(&name[..n]));let _=LOG.set(path.with_file_name("VulcansGift.log"));
 let base=GetModuleHandleW(std::ptr::null()) as usize;BASE.store(base,Ordering::Relaxed);
 let nt=base+u32at(base+0x3c) as usize;
 if u32at(nt+8)!=0x69ce4c84||u32at(nt+24+0x38)!=0x4836000{record("REFUSED game fingerprint mismatch");return}
 if let Err(e)=core_bridge::ensure(&path){log!("REFUSED core bridge: {e}");return}
 // TKMM verifies the selected local version via this file; the official core
 // retains its own original log and inventory in its unchanged version folder.
 let manager_log=path.with_file_name("script_extender.log");
 let _=std::fs::write(&manager_log,"bootstrap complete: official TKMM 0.46.0 core ready; Vulcan's Gift extension starting\n");
 if let Err(e)=playback::prepare_runtime(){log!("REFUSED runtime discovery: {e}");return}
 if read::<8>(base+0x63f940)!=Some([0x48,0x89,0x5c,0x24,0x08,0x48,0x89,0x6c])||read::<8>(base+0x640190)!=Some([0x48,0x89,0x5c,0x24,0x18,0x55,0x57,0x41]){record("REFUSED image anchor mismatch or another hook present");return}
 let p:SetPath=std::mem::transmute(base+0x63f940);let a:Assign=std::mem::transmute(base+0x640190);
 let ph=match GenericDetour::new(p,set_path){Ok(d)=>d,Err(e)=>{log!("REFUSED path detour {e}");return}};
 let ah=match GenericDetour::new(a,assign){Ok(d)=>d,Err(e)=>{log!("REFUSED assign detour {e}");return}};
 let _=PATH_HOOK.set(ph);let _=ASSIGN_HOOK.set(ah);
 let enabled=freeze::with_threads_frozen(base+0x63f940,0x6401c0-0x63f940,||{
  // All detours are published before any jump is enabled.
  ASSIGN_HOOK.get().unwrap().enable()?;
  if let Err(e)=PATH_HOOK.get().unwrap().enable(){let _=ASSIGN_HOOK.get().unwrap().disable();return Err(e)}Ok::<(),retour::Error>(())
 });
 match enabled{Ok(Ok(()))=>{},Ok(Err(e))=>{log!("REFUSED enable {e}");return},Err(e)=>{log!("REFUSED freeze {e}");return}}
 record("READY native APNG hooks installed; source image buffers unchanged; TKMM extender retained");
}}
#[no_mangle]
pub extern "system" fn DllMain(module:*mut c_void,reason:u32,_reserved:*mut c_void)->i32{
 if reason==1{SELF.store(module as usize,Ordering::Relaxed);unsafe{DisableThreadLibraryCalls(module)};std::thread::spawn(bootstrap);}1
}
