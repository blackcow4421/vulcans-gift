#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include "webp/demux.h"
void* vg_webp_new(const uint8_t* bytes, size_t size, uint32_t* width, uint32_t* height, uint32_t* frames, uint32_t* loops) {
 WebPData data = {bytes, size};
 WebPDemuxer* demux = WebPDemux(&data);
 if (!demux) return NULL;
 *width=WebPDemuxGetI(demux, WEBP_FF_CANVAS_WIDTH);
 *height=WebPDemuxGetI(demux, WEBP_FF_CANVAS_HEIGHT);
 *frames=WebPDemuxGetI(demux, WEBP_FF_FRAME_COUNT);
 *loops=WebPDemuxGetI(demux, WEBP_FF_LOOP_COUNT);
 WebPDemuxDelete(demux);
 if (!*width||!*height||!*frames||*width>4096||*height>4096||*frames>10000) return NULL;
 WebPAnimDecoderOptions options;
 if (!WebPAnimDecoderOptionsInit(&options)) return NULL;
 options.color_mode=MODE_RGBA; options.use_threads=1;
 return WebPAnimDecoderNew(&data,&options);
}
int vg_webp_next(void* decoder, uint8_t* output, size_t size, int* timestamp) {
 uint8_t* canvas=NULL;
 if (!WebPAnimDecoderHasMoreFrames((WebPAnimDecoder*)decoder)) return 0;
 if (!WebPAnimDecoderGetNext((WebPAnimDecoder*)decoder,&canvas,timestamp)) return -1;
 WebPAnimInfo info;
 if (!WebPAnimDecoderGetInfo((WebPAnimDecoder*)decoder,&info)||size!=(size_t)info.canvas_width*info.canvas_height*4) return -1;
 memcpy(output,canvas,size);
 return 1;
}
void vg_webp_reset(void* decoder) { WebPAnimDecoderReset((WebPAnimDecoder*)decoder); }
void vg_webp_delete(void* decoder) { WebPAnimDecoderDelete((WebPAnimDecoder*)decoder); }
