fn main(){
 let dir=std::env::var_os("WEBP_STATIC_DIR").map(std::path::PathBuf::from).unwrap_or_else(||std::path::PathBuf::from(std::env::var("CARGO_MANIFEST_DIR").unwrap()).parent().unwrap().join("webp_build"));
 println!("cargo:rustc-link-search=native={}",dir.display());
 for name in ["vg_webp","libwebpdemux","libwebp","libsharpyuv"]{println!("cargo:rustc-link-lib=static={name}");}
 println!("cargo:rerun-if-env-changed=WEBP_STATIC_DIR");
}
