-- Animated unit cards: PNG sequences, APNG and WebP. Preserve native selection highlighting.
local native,sequences,owners={},{},{}
local loaded=false
local states,targets={},{}
local last_scan=-10
local function normal(s)return type(s)=='string' and s:gsub('\\','/'):lower() or '' end
local last_registry_check=-10
local function registry()
 if loaded then return true end
 local now=os.clock();if now-last_registry_check<1 then return false end;last_registry_check=now
 local folder=os.getenv('LOCALAPPDATA');if not folder then return false end
 local f=io.open(folder..'/VulcansGiftNative/runtime_registry.tsv','r');if not f then return false end
 local raw=f:read('*a');f:close()
 if type(raw)~='string' then return false end
 raw=raw:gsub('\r','')
 local header=raw:match('^([^\n]+)')
 if not header or not header:match('^VULCANS_GIFT\t1\t.+')then return false end
 local a,p,o={},{},{};local lines,count=0,0
 for line in raw:gmatch('[^\n]+')do
  local kind,rest=line:match('^([^\t]+)\t(.*)$')
  if kind=='A' then
   lines=lines+1;rest=normal(rest)
   if rest:match('/stills/unitcards/')then a[rest]=true;count=count+1 end
  elseif kind=='P' then
   lines=lines+1;local source,list=rest:match('^([^\t]+)\t(.*)$')
   if source and source:match('/stills/unitcards/')then local frames={};for path in list:gmatch('[^\t]+')do path=normal(path);frames[#frames+1]=path;o[path]=normal(source)end;p[normal(source)]=frames;count=count+1 end
  end
 end
 if count==0 then return false end
 native,sequences,owners=a,p,o;loaded=true;return true
end
local function add_card(u,route)
 local count=u:NumImages();if type(count)~='number'then return end
 for i=0,count-1 do
  local path=normal(u:GetImagePath(i));local source=owners[path]or path
  if native[source]or sequences[source]then targets[#targets+1]={u=u,i=i,source=source,route=route,native=native[source],frames=sequences[source]}end
 end
end
local function direct_child(parent,name)
 if not is_uicomponent(parent)then return false end
 local n=tonumber(parent:ChildCount());if not n then return false end
 for i=0,n-1 do local child=UIComponent(parent:Find(i));if is_uicomponent(child)and child:Id()==name then return child end end
 return false
end
local function direct_path(parent,names)
 for _,name in ipairs(names)do parent=direct_child(parent,name);if not parent then return false end end
 return parent
end
local function campaign_scan(root)
 local list=direct_path(root,{'hud_campaign','modes_holder','strategic_mode','units_parent','units_panel','military_force','retinue_parent','force_retinue_list'})
 if not is_uicomponent(list)or not list:Visible()then return end
 local count=tonumber(list:ChildCount());if not count then return end
 for i=0,count-1 do
  local entry=UIComponent(list:Find(i));local card=direct_path(entry,{'general','unit_card_hero','unit_card_hero'})
  if is_uicomponent(card)and card:Visible()then add_card(card,'campaign/'..i)end
 end
end
local function battle_scan(root)
 local nodes=0
 local function scan(u,depth,route)
  if depth>24 or nodes>20000 or not is_uicomponent(u)or(depth>0 and not u:Visible())then return end
  nodes=nodes+1;add_card(u,route)
  local n=u:ChildCount();if type(n)~='number'then return end
  for i=0,n-1 do scan(UIComponent(u:Find(i)),depth+1,route..'/'..i)end
 end
 scan(root,0,'battle')
end
local stopped=false
local function tick()
 if stopped then return end
 local ok,err=pcall(function()
  if not registry()then return end
  local now=os.clock()
  if now-last_scan>0.5 then
   last_scan=now;targets={};local root=core:get_ui_root()
   if core:is_battle()then battle_scan(root)else campaign_scan(root)end

  end
  local fresh={}
  for _,r in ipairs(targets)do
   if is_uicomponent(r.u)and r.u:Visible()then
    local current=normal(r.u:GetImagePath(r.i))
    if current==r.source or owners[current]==r.source then
     local id=r.route..':'..r.i;local st=states[id]
     local selected=r.u:CurrentState();local on=selected=='selected'or selected=='selected_hover'or selected=='selected_down'
     if not st or st.source~=r.source then st={source=r.source,selected=on,start=now}; end
     if st.selected~=on then st.selected=on;st.start=now; end
     if r.native then r.u:SetImagePath(r.source,r.i)
     else local n=math.floor(math.max(0,now-st.start)*24)+1;local index=(on and n<=#r.frames)and n or 1;r.u:SetImagePath(r.frames[index],r.i)end
     fresh[id]=st
    end
   end
  end
  states=fresh
 end)
 if not ok then stopped=true;local f=io.open('vulcans_gift_errors.log','a');if f then f:write('Card player: '..tostring(err)..'\n');f:close()end end
end
if core:is_battle()then
 local ok,err=pcall(function()
  local manager=type(get_bm)=='function'and get_bm()or bm
  assert(manager and type(manager.register_repeating_timer)=='function','battle raw timer unavailable')
  -- repeat_callback(33) requeues within the engine library's 50ms leeway forever.
  -- A named engine timer bypasses that queue and keeps the 33ms playback cadence.
  _G.vulcans_gift_card_engine_tick=tick
  manager:register_repeating_timer('vulcans_gift_card_engine_tick',33); 
 end)
 if not ok then local f=io.open('vulcans_gift_errors.log','a');if f then f:write('Battle card timer: '..tostring(err)..'\n');f:close()end end
else
 cm:add_first_tick_callback(function()cm:repeat_callback(tick,1/30,'vulcans_gift_cards'); end)
end
 

