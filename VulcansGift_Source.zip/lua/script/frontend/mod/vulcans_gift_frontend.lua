-- Native registry handshake; no external launcher or pre-generated asset pack.
local native_apng,png_sequences={},{}
local registry_loaded,registry_requested=false,false
local registry_token=tostring({})..":"..tostring(os.time())
local last_registry_check=-10
local fallback_cache={}
-- Vulcan's Gift: image-only portrait animation discovery.
-- Frames: ui/vulcans_gift/animations/<source path after ui/>/ani/<stem>_000.png
local PERIOD,FRAME_SECONDS=1/120,1/24
local ADVISOR_FRAME_SECONDS=1/30
local definitions,owners,states={},{},{}
local stopped=false
local hidden_layers,layer_records={},{}
local function log(s)
 local f=io.open("vulcans_gift.log","a")
 if f then f:write(tostring(s).."\n");f:close() end
end
local function normal(s)
 return type(s)=="string" and string.lower(string.gsub(s,"\\","/")) or ""
end
local function load_native_registry()
 if registry_loaded then return end
 local now=os.clock();if now-last_registry_check<0.5 then return end;last_registry_check=now
 local folder=os.getenv('LOCALAPPDATA');if not folder then return end
 folder=folder..'/VulcansGiftNative/'
 if not registry_requested then
  local f=io.open(folder..'runtime_request.txt','w')
  if not f then return end;f:write(registry_token,'\n');f:close();registry_requested=true
 end
 local f=io.open(folder..'runtime_registry.tsv','r');if not f then return end
 local first=f:read('*l')
 if first~='VULCANS_GIFT\t1\t'..registry_token then f:close();return end
 local a,p={},{}
 for line in f:lines() do
  local kind,rest=line:match('^([^\t]+)\t(.*)$')
  if kind=='A' then a[rest]=true
  elseif kind=='P' then
   local source,frames=rest:match('^([^\t]+)\t(.*)$')
   if source then local list={};for path in frames:gmatch('[^\t]+') do list[#list+1]=path end;p[source]=list end
  end
 end
 f:close();native_apng=a;png_sequences=p;definitions={};fallback_cache={};registry_loaded=true
 log('Native runtime registry connected; PNG sequences retained')
end
local function discover(source)
 if definitions[source]~=nil then return definitions[source] end
 if native_apng[source] then local frames={source};frames.native_apng=true;definitions[source]=frames;return frames end
 local indexed=png_sequences[source];if indexed then definitions[source]=indexed;for _,p in ipairs(indexed) do owners[p]=source end;return indexed end
 definitions[source]=false
 local folder,stem=source:match("^(.-)([^/]+)%.png$")
 if not folder then log('No PNG stem: '..source);return false end
 folder='ui/vulcans_gift/animations/'..folder:sub(4)..'ani/'
 log('Lookup: '..folder..stem..'_*.png')
 local listing=effect.filesystem_lookup("/"..folder,stem.."_*.png")
 if type(listing)~="string" then error("PNG lookup returned "..type(listing)) end
 local found={}
 for item in listing:gmatch("([^,]+)") do
  local name=normal(item):match("([^/]+)$")
  if name then found[name]=true end
 end
 local frames={}
 local i=0
 while true do
  local name=stem.."_"..string.format("%03d",i)..".png"
  if not found[name] then break end
  frames[#frames+1]=folder..name
  i=i+1
 end
 if #frames==0 then
  log("Static: "..source.."; lookup="..listing)
  return false
 end
 definitions[source]=frames
 for _,path in ipairs(frames) do owners[path]=source end
 log("Discovered "..#frames.." frames: "..source)
 return frames
end
-- Resolve expressions from the vanilla character-details satisfaction binding.
-- character_frame_neutral is not an expression: happy also appears there.
-- Keep different component parts (face, torso, arms) in separate families.
local emotions={norm=true,happy=true,angry=true}
local function family(source,route)
 if not route:match("^portrait/") then return nil end
 local folder,expression,stem=source:match('^(.-)/([^/]+)/([^/]+)%.png$')
 if not folder or not emotions[expression] then return nil end
 if emotions[stem] then stem='@expression' end
 local parent=route:match('^(.*)/[^/]+$') or route
 return parent..'|'..folder..'|'..stem
end
local function expression(source)
 return source:match('/(happy)/[^/]+%.png$') or
        source:match('/(angry)/[^/]+%.png$') or
        source:match('/(norm)/[^/]+%.png$')
end
-- Prefer the current expression; reuse another expression only when missing.
-- Preserve part basenames, and map emotion-named files to the sibling emotion.
local function portrait_frames(source)
 if fallback_cache[source]~=nil then return fallback_cache[source] end
 local frames=discover(source)
 local folder,e,stem=source:match('^(.-)/([^/]+)/([^/]+)%.png$')
 if not frames and folder and emotions[e] then
  for _,other in ipairs({'norm','happy','angry'}) do
   if other~=e then
    local name=emotions[stem] and other or stem
    frames=discover(folder..'/'..other..'/'..name..'.png')
    if frames then break end
   end
  end
 end
 fallback_cache[source]=frames
 return frames
end
local function selected_expression(panel)
 -- Do not use child order or character_frame_neutral as an emotion signal.
 -- This label is bound to CcoCampaignCharacter.SatisfactionValue in vanilla.
 -- Hidden/missing labels (e.g. faction leaders or custom UI) are not trusted.
 local ok,value=pcall(function()
  local label=find_uicomponent(panel,"satisfaction")
  if not is_uicomponent(label) or not label:Visible() then return nil end
  local text=label:GetStateText()
  if type(text)~="string" then return nil end
  text=text:gsub("%[%[.-%]%]", "")
  return tonumber(text:match("^%s*(%d+)%s*$"))
 end)
 if not ok or not value or value<0 or value>100 then return nil end
 if value<=19 then return "angry" end
 if value>=80 then return "happy" end
 return "norm"
end
local last_selection
local family_history={}
local function native_expression(u)
 local ok,e=pcall(function() return normal(u:GetProperty("expr")) end)
 if not ok then return nil end
 if e=="normal" then e="norm" end
 return emotions[e] and e or nil
end
local function choose_expression(g,selected,previous)
 local property,property_conflict,unique,ambiguous
 local present={}
 for _,r in ipairs(g) do
  local e=expression(r.source)
  present[e]=true
  if unique and unique~=e then ambiguous=true end
  unique=unique or e
  if r.native_expression then
   if property and property~=r.native_expression then property_conflict=true end
   property=property or r.native_expression
  end
 end
 local choice,reason
 -- A current bound satisfaction value outranks a branch's default property
 -- and the order in which image resources happened to be loaded.
 if selected then choice=selected;reason="current satisfaction"
 elseif property and not property_conflict and present[property] then
  choice=property;reason="branch expression"
 elseif not ambiguous then choice=unique;reason="single native expression"
 else choice="norm";reason="ambiguous defaults to norm" end
 if not choice then choice="norm";reason="unknown defaults to norm" end
 -- History is diagnostic only. Never infer current emotion from last choice.
 if not previous or choice~=previous.choice or reason~=previous.reason then
  log("Family v6: "..choice.." ("..reason..") "..g[1].family)
  local names={}
  for e in pairs(present) do names[#names+1]=e end
  table.sort(names)
  log("Evidence v6: present="..table.concat(names,",")..
   "; satisfaction="..tostring(selected).."; property="..tostring(property)..
   "; property_conflict="..tostring(property_conflict))
 end
 return choice,{choice=choice,reason=reason}
end
local function restore_one(item)
 pcall(function()
  if is_uicomponent(item.u) then
   local path=normal(item.u:GetImagePath(item.i))
   if (owners[path] or path)==item.source then item.u:SetVisible(true) end
  end
 end)
end
local function restore_layers()
 for _,item in pairs(hidden_layers) do restore_one(item) end
 hidden_layers={}
end
local function walk(u,depth,route,inherited_expression)
 if depth>18 or not is_uicomponent(u) then return end
 local owned=hidden_layers[route]
 if not u:Visible() and not owned then return end
 local id=u:Id()
 if id=="character_frame_neutral" or id=="character_frame_expression" then
  inherited_expression=native_expression(u)
 end
 local count=u:NumImages()
 if type(count)~='number' then return end
 for i=0,count-1 do
  local current=normal(u:GetImagePath(i))
  local previous=states[route..":"..i]
  local source=(previous and previous.last_frame==current and previous.source) or owners[current] or current
  layer_records[#layer_records+1]={u=u,i=i,route=route,current=current,
   source=source,image_count=count,family=family(source,route),native_expression=inherited_expression}
 end
 for i=0,u:ChildCount()-1 do
  local child=UIComponent(u:Find(i))
  walk(child,depth+1,route.."/"..i..":"..child:Id(),inherited_expression)
 end
end
local function resolve_layers(selected)
 local groups={}
 for _,r in ipairs(layer_records) do
  if r.family and r.image_count==1 then
   local g=groups[r.family];if not g then g={};groups[r.family]=g end;g[#g+1]=r
  end
 end
 local next_hidden,history={},{}
 for key,g in pairs(groups) do
  local choice,record=choose_expression(g,selected,family_history[key]);history[key]=record
  local winner
  -- Direct animation wins over a static expression, even at another satisfaction.
  for _,r in ipairs(g) do
   r.frames=discover(r.source)
   if r.frames and (not winner or expression(r.source)==choice) then winner=r end
  end
  -- Native UI may expose only the current expression's image component.
  if not winner then
   for _,r in ipairs(g) do
    r.frames=portrait_frames(r.source)
    if r.frames and (not winner or expression(r.source)==choice) then winner=r end
   end
  end
  if winner then
   for _,r in ipairs(g) do
    if r~=winner then
     r.suppressed=true
     if r.current~=r.source then r.u:SetImagePath(r.source,r.i) end
     if r.u:Visible() then r.u:SetVisible(false) end
     next_hidden[r.route]={u=r.u,i=r.i,source=r.source}
    end
   end
  end
 end
 for route,item in pairs(hidden_layers) do
  local next_item=next_hidden[route]
  if not next_item or next_item.source~=item.source then restore_one(item) end
 end
 hidden_layers=next_hidden;family_history=history
end

local function play_layers(fresh,now)
 for _,r in ipairs(layer_records) do
  if not r.suppressed then
   local frames=r.frames
   if frames==nil then frames=discover(r.source) end
   if frames then
    local id=r.route..":"..r.i
    local state=states[id]
    if not state or state.animation~=frames[1] then
     state={u=r.u,source=r.source,animation=frames[1],started=now}
     if frames.native_apng then log('Native target ['..r.route..'] '..frames[1]) end
    end
    state.source=r.source
    local seconds=r.route:match("^advisor") and ADVISOR_FRAME_SECONDS or FRAME_SECONDS
    local index=math.floor(math.max(0,now-state.started)/seconds+0.000001)%#frames+1
    if frames.native_apng or r.current~=frames[index] then r.u:SetImagePath(frames[index],r.i) end
    state.last_frame=frames[index]
    fresh[id]=state
   end
  end
 end
end
local TIMER="vulcans_gift_faction_selection_tick"
local registered=false
local function collect_fullbody(u,depth,route)
 if depth>8 or not is_uicomponent(u) or not u:Visible() then return end
 if u:Id()=="fullbody_character" then
  walk(u,0,route)
  return
 end
 for i=0,u:ChildCount()-1 do
  local child=UIComponent(u:Find(i))
  collect_fullbody(child,depth+1,route.."/"..i..":"..child:Id())
 end
end
local function tick()
 if stopped then return end
 local ok,err=pcall(function()
  load_native_registry()
  local root=core:get_ui_root()
  local fresh={}
  layer_records={}
  local panel=find_uicomponent(root,"new_campaign")
  if is_uicomponent(panel) and panel:Visible() then
   local parent=find_uicomponent(panel,"selected_character_parent")
   if is_uicomponent(parent) and parent:Visible() then
    -- Includes selected_faction_leader and the four noteworthy-character
    -- slots. Map pins and small selection cards are outside this subtree.
    collect_fullbody(parent,0,"portrait/frontend")
   end
  end
  -- Frontend advice, when present: animate only the portrait subtree.
  local advice=find_uicomponent(root,"advice_interface")
  if is_uicomponent(advice) and advice:Visible() then
   local hider=find_uicomponent(advice,"help_hider")
   local parent=is_uicomponent(hider) and hider:Visible() and find_uicomponent(hider,"advisor_portrait_parent")
   local portrait=is_uicomponent(parent) and parent:Visible() and find_uicomponent(parent,"default_portrait")
   if is_uicomponent(portrait) and portrait:Visible() then walk(portrait,0,"advisor/frontend") end
  end
  resolve_layers(nil)
  play_layers(fresh,os.clock())
  states=fresh
 end)
 if not ok then
  restore_layers();stopped=true;states={}
  pcall(function()real_timer.unregister(TIMER)end)
  log("Frontend stopped: "..tostring(err))
 end
end
local function install()
 if registered then return end
 local ok,err=pcall(function()
  if not effect or type(effect.filesystem_lookup)~="function" then error("frontend filesystem lookup unavailable") end
  if not real_timer or type(real_timer.register_repeating)~="function" then error("frontend real_timer unavailable") end
  core:add_listener(TIMER,"RealTimeTrigger",
   function(context)return context.string==TIMER end,tick,true)
  real_timer.register_repeating(TIMER,16)
  registered=true
 end)
 log(ok and "Vulcan Gift frontend v1: large faction portraits 24 fps" or ("Frontend registration failed: "..tostring(err)))
end
-- Vanilla frontend mod loader runs before the UI exists.
core:add_listener("vulcans_gift_frontend_created","UICreated",true,install,true)
core:add_listener("vulcans_gift_frontend_transition","FrontendScreenTransition",true,install,true)
